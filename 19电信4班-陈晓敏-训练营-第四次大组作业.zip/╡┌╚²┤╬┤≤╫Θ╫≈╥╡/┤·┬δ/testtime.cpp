#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "qgsort.h"
#include <time.h>
#define CLOCKS_PER_SEC ((clock_t)1000)
typedef long clock_t;
#define num 100


void for_a()
{
	printf("************1w����**********\n");
	int n = 10000;
	int *a = (int *)malloc(sizeof(int) * n);
	memset(a, 0, n * sizeof(int));
	int *temp = (int *)malloc(sizeof(int) * n);
	memset(temp, 0, n * sizeof(int));
	srand((int)time(0));
	clock_t start, finish;
	double  duration;

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	MergeSort(a, 0, n - 1, temp);
	finish = clock();
	duration = (double)(finish - start);
	printf("�鲢��ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	QuickSort_Recursion(a, 0, n - 1);
	finish = clock();
	duration = (double)(finish - start);
	printf("���ŵݹ���ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	CountSort(a, n, findmax(a, n));
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	RadixCountSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("����������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	insertSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);


	free(a);
	free(temp);
	system("pause");

}

void for_b()
{
	printf("************5w����**********\n");
	int n = 50000;
	int *a = (int *)malloc(sizeof(int) * n);
	memset(a, 0, n * sizeof(int));
	int *temp = (int *)malloc(sizeof(int) * n);
	memset(temp, 0, n * sizeof(int));
	srand((int)time(0));
	clock_t start, finish;
	double  duration;

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	MergeSort(a, 0, n - 1, temp);
	finish = clock();
	duration = (double)(finish - start);
	printf("�鲢��ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	QuickSort_Recursion(a, 0, n - 1);
	finish = clock();
	duration = (double)(finish - start);
	printf("���ŵݹ���ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	CountSort(a, n, findmax(a, n));
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	RadixCountSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("����������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	insertSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);


	free(a);
	free(temp);
	system("pause");

}

void for_c()
{
	printf("************20w����**********\n");
	int n = 200000;
	int *a = (int *)malloc(sizeof(int) * n);
	memset(a, 0, n * sizeof(int));
	int *temp = (int *)malloc(sizeof(int) * n);
	memset(temp, 0, n * sizeof(int));
	srand((int)time(0));
	clock_t start, finish;
	double  duration;

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	MergeSort(a, 0, n - 1, temp);
	finish = clock();
	duration = (double)(finish - start);
	printf("�鲢��ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	QuickSort_Recursion(a, 0, n - 1);
	finish = clock();
	duration = (double)(finish - start);
	printf("���ŵݹ���ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	CountSort(a, n, findmax(a, n));
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	RadixCountSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("����������ʱ��%f ms\n", duration);

	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % 1000 + 1;
	}
	start = clock();
	insertSort(a, n);
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);


	free(a);
	free(temp);
	system("pause");

}

void for_d()
{
	printf("************100*100k����**********\n");
	int n = 100000, k = 100;
	int *a = (int *)malloc(sizeof(int) * k);
	memset(a, 0, k * sizeof(int));
	int *temp = (int *)malloc(sizeof(int) * k);
	memset(temp, 0, k * sizeof(int));

	srand((int)time(0));
	clock_t start, finish;
	double  duration;

	start = clock();
	for (int i = 0; i < n; i++)
	{
		for (int m = 0; m < k; m++)
		{
			a[m] = rand() % 1000 + 1;
		}
		MergeSort(a, 0, k - 1, temp);
	}
	finish = clock();
	duration = (double)(finish - start);
	printf("�鲢��ʱ��%f ms\n", duration);

	start = clock();
	for (int i = 0; i < n; i++)
	{
		for (int m = 0; m < k; m++)
		{
			a[m] = rand() % 1000 + 1;
		}
		QuickSort_Recursion(a, 0, k - 1);
	}
	finish = clock();
	duration = (double)(finish - start);
	printf("���ŷǵݹ���ʱ��%f ms\n", duration);

	start = clock();
	for (int i = 0; i < n; i++)
	{
		for (int m = 0; m < k; m++)
		{
			a[m] = rand() % 1000 + 1;
		}
		CountSort(a, k, findmax(a, k));
	}
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);

	start = clock();
	for (int i = 0; i < n; i++)
	{
		for (int m = 0; m < k; m++)
		{
			a[m] = rand() % 1000 + 1;
		}
		RadixCountSort(a, k);
	}
	finish = clock();
	duration = (double)(finish - start);
	printf("����������ʱ��%f ms\n", duration);

	start = clock();
	for (int i = 0; i < n; i++)
	{
		for (int m = 0; m < k; m++)
		{
			a[m] = rand() % 1000 + 1;
		}
		insertSort(a, k);
	}
	finish = clock();
	duration = (double)(finish - start);
	printf("������ʱ��%f ms\n", duration);

	free(a);
	free(temp);
	system("pause");
}

void srand_test()
{
	int *a = (int *)malloc(sizeof(int) * num);
	memset(a, 0, num * sizeof(int));

	//int a[num] = { 0 };
	number(num);
	read_file(a, num);
	printf("����ǰ��\n");
	Print(a, num);
	RadixCountSort(a, num);
	printf("�����\n");
	Print(a, num);

	free(a);
	system("pause");
}

