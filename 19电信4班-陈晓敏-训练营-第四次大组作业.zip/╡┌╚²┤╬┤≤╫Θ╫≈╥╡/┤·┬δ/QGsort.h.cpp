﻿// QGsort.h.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "qgsort.h"
#include <time.h>
#include <conio.h>
#define CLOCKS_PER_SEC ((clock_t)1000)
#define num 1000
typedef long clock_t;

int main()
{
	char n, key = 0;
	int flag = 1;
	int m = 10;

	do
	{
		printf("请选择你要测试的规模\n");
		printf("a.1w\nb.5w\nc.20w\nd.100*100k\ne.随机生成数据写入文件并排序\nf.退出\n");
		scanf("%c", &n);
		getchar();
		switch (n)
		{
		case 'a':
		{
			for_a();
			break;
		}
		case 'b':
		{
			for_b();
			break;
		}
		case 'c':
		{
			for_c();
			break;
		}
		case 'd':
		{
			for_d();
			break;
		}
		case 'e':
		{
			srand_test();
			break;
		}
		case 'f':printf("goodbye\n"); system("pause"); flag = 0; break;

		default:printf("your enter is wrong!\n"); system("pause");
		}
		printf("继续执行请按回车或esc键\n");
		for (; key != 13 && key != 27;)
			key = _getch();

		system("cls");
		//system("pause");
	} while (flag);


	return 0;
}
