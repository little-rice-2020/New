
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>


void PushOperation(char *opera, char *ss, int *op, int *s)
{
	opera[*op] = ss[*s];
	(*op)++;
	(*s)++;
}

void Calculate(double *num, int *i, int *j, char s)
{
	switch (s)
	{
	case '+':
	{
		num[(*j) - 2] = num[(*j) - 2] + num[(*j) - 1];
		//	printf("%lf = %lf + %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '-':
	{
		num[(*j) - 2] = num[(*j) - 2] - num[(*j) - 1];
		//	printf("%lf = %lf - %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '*':
	{
		num[(*j) - 2] = num[(*j) - 2] * num[(*j) - 1];
		//	printf("%lf = %lf * %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '/':
	{
		num[(*j) - 2] = num[(*j) - 2] / num[(*j) - 1];
		//	printf("%lf = %lf / %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	default:
	{
		exit(0);
	}
	}
}

void suffix(char *ss)
{
	char num[100] = "0";    /* �洢��׺����ʽ */
	char opera[100] = "0";    /* �洢����� */
	/*
	num----j
	opera----op
	ss----i
	*/
	int i, j, op;
	op = i = j = 0;

	while (ss[i] != '\0')
	{
		if (isdigit(ss[i])) /*���ÿ⺯�����ж��Ƿ�Ϊ0~9������ */
		{
			num[j] = ss[i];    
			j++;
			i++;
		}
		else
		{
			switch (ss[i])    
			{
			case '+':
			{
				if (op == 0)   
				{
					PushOperation(opera, ss, &op, &i);   
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];    
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;

						break;
					}
					case '*':
					{    
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];    
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];   
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '-':
			{
				/*	if (ss[i - 1] == '(')
					{
						num[j] = '0';
						j++;
					//	printf("%s", ss[i - 1]);
					}
				*/

				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];   
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;

						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];    
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];    
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '*':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '/':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];   
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '/':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];   
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '(':
			{
				PushOperation(opera, ss, &op, &i);
				break;
			}
			case ')':   
			{
				while (opera[op - 1] != '(')
				{
					num[j] = opera[op - 1]; 
					j++;
					op--;
				}
				op--;
				i++;
				break;
			}
			default:
			{
				printf("�������ʽ������Ҫ��\n");
				exit(0);
			}

			}
		}
	}
	while (op != 0)
	{
		num[j] = opera[op - 1];  
		j++;
		op--;
	}
	num[j] = '\0';
	i = 0;
	while (num[i] != '\0')  
	{
		ss[i] = num[i];
		i++;
	}
	ss[i] = '\0';

}
