﻿// 计算器.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#define MAX 100


int main()
{
	void suffix(char *ss); /* 计算后缀表达式 */
	void Calculate(double *num, int *i, int *j, char s);    /* 计算结果并入栈 */

	char ss[MAX] = { "\0" };  /* 存储后缀表达式 */
	printf("input:\n");/*注意输入的是0~9的数字*/
	gets_s(ss);
	suffix(ss);
	puts(ss);

	int i = 0;
	int j = 0;
	double num[MAX];  

	while (ss[i] != '\0')
	{
		if (ss[i] >= '0' && ss[i] <= '9')   
		{
			num[j] = (double)(ss[i] - '0'); 
			j++;
			i++;
		}
		else if (ss[i] == '+' || ss[i] == '-' || ss[i] == '*' || ss[i] == '/')
		{
			Calculate(num, &i, &j, ss[i]);   
		}
		else if (ss[i] == '\n')    
		{
			break;
		}
	}
	//printf("%d\n", j);
	printf("result:\n");
	printf("%lf", num[0]);

	return 0;
}






// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
