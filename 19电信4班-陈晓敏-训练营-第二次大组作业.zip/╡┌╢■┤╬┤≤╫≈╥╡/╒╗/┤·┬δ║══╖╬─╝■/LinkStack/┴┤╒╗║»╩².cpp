
#define _CRT_SECURE_NO_WARNINGS
#include "LinkStack.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>


//��ʼ��ջ
Status initLStack(LinkStack *s) 
{
    s->top = (LinkStackPtr)malloc(sizeof(StackNode));
        if (!s->top)
            return ERROR;
    
        s->top = NULL;
        s->count = 0;
        return SUCCESS;
}
//�ж�ջ�Ƿ�Ϊ�� 
Status isEmptyLStack(LinkStack *s)
{
    if (s->top == NULL)
    {
        printf("ջΪ��\n");
        return SUCCESS;
    }
        
    else
        return ERROR;
}
//����ջ
int Traverse(LinkStack *s) 
{
    int i;
    if (isEmptyLStack(s) == SUCCESS) return ERROR;
	LinkStackPtr p = s->top;
    for(i=s->count;i>0;i--)
    {
        
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
    return SUCCESS;
}
//��ջ
Status pushLStack(LinkStack *s, ElemType data)
{
       
	LinkStackPtr p = (LinkStackPtr)malloc(sizeof(StackNode));
    if (!p)  return ERROR;
        p->data = data;
        p->next = s->top;   
        s->top = p;          
        s->count++;      
    
        return SUCCESS;

}
// �õ�ջ��Ԫ��
Status getTopLStack(LinkStack *s, ElemType *e)
{
    if (isEmptyLStack(s) == SUCCESS) return ERROR;
    *e = s->top->data;
    return SUCCESS;
}
//��ջ
Status popLStack(LinkStack *s, ElemType *data)
{
    if (isEmptyLStack(s) == SUCCESS) return ERROR;
        
	LinkStackPtr temp = s->top;
	*data = temp->data;
    s->top = temp->next;
    s->count--;
    free(temp);
    return SUCCESS;
}
//����ջ
Status destroyLStack(LinkStack *s) 
{
	LinkStackPtr p,q=NULL;
    if(isEmptyLStack(s)== SUCCESS) return ERROR;
    p = s->top;
    for (int i = s->count; i > 0; i--)
    {
        q = p->next;
        free(p);
        p = q;
    }
    s->count = 0; 
    return SUCCESS;
}

int main() 
{
    LinkStack s,*p;
    ElemType a, *e;
    e = (ElemType*)malloc(sizeof(ElemType));
    p = &s;
	initLStack(p);
    int n;
	isEmptyLStack(p);
    printf("��������ջԪ�صĸ���:");
    scanf("%d", &n);
	printf("��������ջԪ��, ���ո������\n");
    for(int i=0;i<n;i++)
    {
        scanf("%d", &a);
		pushLStack(p, a);
    }
	printf("�洢��ջ���Ԫ��Ϊ\n");
    Traverse(p);
	popLStack(p, e);
    printf("��ջ��Ԫ��Ϊ%d\n", *e);
	printf("����ջ���Ԫ��Ϊ\n");
    Traverse(p);
	getTopLStack(p, e);
    printf("ջ��Ԫ��Ϊ%d\n", *e);
    if(destroyLStack(p)== SUCCESS) printf("ջ���ٳɹ���");

    return 0;
}
