﻿// 链栈.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//


#define _CRT_SECURE_NO_WARNINGS
#include "LinkStack.h"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>


//初始化栈
Status initLStack(LinkStack *s)
{
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	if (!s->top)
		return ERROR;

	s->top = NULL;
	s->count = 0;
	return SUCCESS;
}
//判断栈是否为空 
Status isEmptyLStack(LinkStack *s)
{
	if (s->top == NULL)
	{
		printf("栈为空\n");
		return SUCCESS;
	}

	else
		return ERROR;
}
//遍历栈
int Traverse(LinkStack *s)
{
	int i;
	if (isEmptyLStack(s) == SUCCESS) return ERROR;
	LinkStackPtr p = s->top;
	for (i = s->count; i > 0; i--)
	{

		printf("%d ", p->data);
		p = p->next;
	}
	printf("\n");
	return SUCCESS;
}
//入栈
Status pushLStack(LinkStack *s, ElemType data)
{

	LinkStackPtr p = (LinkStackPtr)malloc(sizeof(StackNode));
	if (!p)  return ERROR;
	p->data = data;
	p->next = s->top;
	s->top = p;
	s->count++;

	return SUCCESS;

}
// 得到栈顶元素
Status getTopLStack(LinkStack *s, ElemType *e)
{
	if (isEmptyLStack(s) == SUCCESS) return ERROR;
	*e = s->top->data;
	return SUCCESS;
}
//出栈
Status popLStack(LinkStack *s, ElemType *data)
{
	if (isEmptyLStack(s) == SUCCESS) return ERROR;

	LinkStackPtr temp = s->top;
	*data = temp->data;
	s->top = temp->next;
	s->count--;
	free(temp);
	return SUCCESS;
}
//销毁栈
Status destroyLStack(LinkStack *s)
{
	LinkStackPtr p, q = NULL;
	if (isEmptyLStack(s) == SUCCESS) return ERROR;
	p = s->top;
	for (int i = s->count; i > 0; i--)
	{
		q = p->next;
		free(p);
		p = q;
	}
	s->count = 0;
	return SUCCESS;
}

int main()
{
	LinkStack s, *p;
	ElemType a, *e;
	e = (ElemType*)malloc(sizeof(ElemType));
	p = &s;
	initLStack(p);
	int n;
	isEmptyLStack(p);
	printf("请输入入栈元素的个数:");
	scanf("%d", &n);
	printf("请输入入栈元素, 按空格键隔开\n");
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a);
		pushLStack(p, a);
	}
	printf("存储在栈里的元素为\n");
	Traverse(p);
	popLStack(p, e);
	printf("出栈的元素为%d\n", *e);
	printf("现在栈里的元素为\n");
	Traverse(p);
	getTopLStack(p, e);
	printf("栈顶元素为%d\n", *e);
	if (destroyLStack(p) == SUCCESS) printf("栈销毁成功！");

	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
