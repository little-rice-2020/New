﻿// 栈.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "SqStack.h"

Status initStack(SqStack *s, int sizes);
Status isEmptyStack(SqStack *s);
SqStack *creat_SqStack();
Status getTopStack(SqStack *s);
Status clearStack(SqStack *s);
Status destroyStack(SqStack *s);
Status stackLength(SqStack *s);
Status pushStack(SqStack *s);
Status popStack(SqStack *s);//出栈


int main()
{
	SqStack *s;
	s = creat_SqStack();

	char input, flag = 1;
	int n1=0, n2=0, n3=0, n4=0;
	do
	{
		int i = 0;
		printf("选择你要进行的操作\n");
		printf("a.初始化栈\n""b.判断栈是否为空\n""c.输出栈顶元素\n""d.清空栈\n"
			"e.销毁栈\n""f.检测栈长度\n""g.入栈\n""h.出栈\n"
			"j.退出操作程序\n");

		input = getchar();
		switch (input)
		{
		case 'a':
		{
			int len;
			printf("请输入创建的栈长度：\n");
			scanf("%d", &len);
			initStack(s, len);
			n1 = 1;
			system("pause");
			break; 
		}
		case 'b': 
		{
			if (n1 == 1)
			{
				isEmptyStack(s);
				n2 = 1;
			}
		else
			printf("请先初始化函数\n");
		system("pause");
		break; }

		case 'c': 
		{
			if (n1 == 1)
			{
				getTopStack(s);
				n3 = 1;
			}
			else
			printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'd':
		{
			if (n1 == 1&& clearStack(s))
			{
				printf("栈已清空\n");
				n4 = 1;
			}
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'e':
		{	
			if (n1 == 1)
				destroyStack(s);
			else
				printf("请先初始化函数\n");
		
			system("pause");  break;
		}
		case 'f':
		{
			if (n1 == 1|| n4 != 1)
				stackLength(s);
			else
				printf("请先初始化函数\n");			
			system("pause");  break;
		}

		
		case 'g':
		{
				pushStack(s);
			system("pause");  break;
		}
		case 'h':
		{
			popStack(s);
			system("pause");  break;
		}

		case 'j':  printf("goodbye\n"); system("pause"); flag = 0; break;

		default:  printf("Your input is wrong! \n"); system("pause"); break;
		}
		while (getchar() != '\n')
		{
			continue;
		}
		system("cls");
	
	} while (flag);
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
