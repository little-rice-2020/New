//��׺ת��׺���������

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#define MAX 100
#define _CRT_SECURE_NO_WARNINGS
#include "caculator_tree.h"
char a[50] = { 0 };


void visit(char e)
{
	printf("%c ", e);
}

BinTreeNode* CreateNode(char ch)
{
	BinTreeNode* temp;
	temp = (BinTreeNode*)malloc(sizeof(BinTreeNode));
	temp->Left = NULL;
	temp->Right = NULL;
	temp->Element = ch;
	return temp;
}

void PreTrversal(BinTreeNode* Tree)
{
	static int i = 0;
	if (Tree)
	{
		a[i] = Tree->Element;
		visit(Tree->Element);
		i++;
		//if (Tree->Left != NULL)
		PreTrversal(Tree->Left);
		//if (Tree->Right != NULL)
		PreTrversal(Tree->Right);
	}
}
void PostTraversal(BinTreeNode* Tree)
{
	static int i = 0;
	if (Tree)
	{
		PostTraversal(Tree->Left);
		PostTraversal(Tree->Right);
		visit(Tree->Element);
		a[i] = Tree->Element;
		i++;
	}
}
void DestroyTree(BinTreeNode* Tree)
{
	if (Tree)
	{
		DestroyTree(Tree->Left);
		DestroyTree(Tree->Right);
		free(Tree);
	}
}

BinTreeNode* create_tree()
{
	void suffix(char *ss);
	void Calculate(double *num, int *i, int *j, char s);

	char ss[MAX] = { "\0" };
	printf("��������׺����ʽ��ע���������0~9�����֣�:\n");
	gets_s(ss);
	suffix(ss);

	char data[100];
	BinTreeNode* stack[100];
	int top = -1;
	strcpy(data, ss);

	for (int i = 0; data[i] != '\0'; i++) {
		if (strchr("+-*/", data[i]) != NULL) {
			BinTreeNode* temp = CreateNode(data[i]);
			BinTreeNode* t1 = stack[top--];
			BinTreeNode* t2 = stack[top--];
			temp->Left = t2;
			temp->Right = t1;
			stack[++top] = temp;
		}
		else {
			BinTreeNode* temp = CreateNode(data[i]);
			stack[++top] = temp;
		}
	}
	BinTreeNode* Tree = stack[top];

	return Tree;
}
int Value(BinTreeNode* T)
{
	void PostTraversal(BinTreeNode* Tree);
	void Calculate(double *num, int *i, int *j, char s);

	int i = 0;
	int j = 0;
	double num[MAX];

	while (a[i] != '\0')
	{
		if (a[i] >= '0' && a[i] <= '9')
		{
			num[j] = (double)(a[i] - '0');
			j++;
			i++;
		}
		else if (a[i] == '+' || a[i] == '-' || a[i] == '*' || a[i] == '/')
		{
			Calculate(num, &i, &j, a[i]);
		}
		else if (a[i] == '\n')
		{
			break;
		}
	}

	printf("\n�ñ���ʽ�ļ�����Ϊ:");
	printf("%.2f", num[0]);

	DestroyTree(T);
	return 0;
}

int caculator_Value()
{
	BinTreeNode* create_tree();
	int Value(BinTreeNode* T);
	BinTreeNode* T = create_tree();

	printf("�ñ���ʽ��ǰ��������Ϊ��");
	PreTrversal(T);
	printf("\n");
	printf("�ñ���ʽ�ĺ���������Ϊ��");
	PostTraversal(T);

	Value(T);
	
	return 0;
}


void PushOperation(char *opera, char *ss, int *op, int *s)
{
	opera[*op] = ss[*s];
	(*op)++;
	(*s)++;
}

void Calculate(double *num, int *i, int *j, char s)
{
	switch (s)
	{
	case '+':
	{
		num[(*j) - 2] = num[(*j) - 2] + num[(*j) - 1];
		(*j)--;
		(*i)++;
		break;
	}
	case '-':
	{
		num[(*j) - 2] = num[(*j) - 2] - num[(*j) - 1];
		(*j)--;
		(*i)++;
		break;
	}
	case '*':
	{
		num[(*j) - 2] = num[(*j) - 2] * num[(*j) - 1];
		(*j)--;
		(*i)++;
		break;
	}
	case '/':
	{
		num[(*j) - 2] = num[(*j) - 2] / num[(*j) - 1];
		(*j)--;
		(*i)++;
		break;
	}
	default:
	{
		exit(0);
	}
	}
}

void suffix(char *ss)
{
	char num[100] = "0";    
	char opera[100] = "0";   
	
	int i, j, op;
	op = i = j = 0;

	while (ss[i] != '\0')
	{
		if (isdigit(ss[i])) /*���ÿ⺯�����ж��Ƿ�Ϊ0~9������ */
		{
			num[j] = ss[i];
			j++;
			i++;
		}
		else
		{
			switch (ss[i])
			{
			case '+':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;

						break;
					}
					case '*':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '-':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;

						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '*':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '/':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '/':
			{
				if (op == 0)
				{
					PushOperation(opera, ss, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '*':
					{
						while ((op - 1) != -1)
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = ss[i];
						i++;
						break;
					}
					case '/':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					case '(':
					{
						PushOperation(opera, ss, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '(':
			{
				PushOperation(opera, ss, &op, &i);
				break;
			}
			case ')':
			{
				while (opera[op - 1] != '(')
				{
					num[j] = opera[op - 1];
					j++;
					op--;
				}
				op--;
				i++;
				break;
			}
			default:
			{
				printf("�������ʽ������Ҫ��\n");
				exit(0);
			}

			}
		}
	}
	while (op != 0)
	{
		num[j] = opera[op - 1];
		j++;
		op--;
	}
	num[j] = '\0';
	i = 0;
	while (num[i] != '\0')
	{
		ss[i] = num[i];
		i++;
	}
	ss[i] = '\0';
}
