﻿#include <iostream>
#include "caculator_tree.h"

int main()
{
	/*
	char input, flag = 1;
	do
	{
		int i = 0;
		printf("选择你要进行的操作\n");
		printf("a.输入一个中缀表达式并计算值\n""b.退出操作程序\n");
		input = getchar();
		switch (input)
		{
		case 'a':
		{
			caculator_Value();
			system("pause");
			break;
		}
		case 'b':  printf("goodbye\n"); system("pause"); flag = 0; break;

		default:  printf("Your input is wrong! \n"); system("pause"); break;
		}
		while (getchar() != '\n')
		{
			continue;
		}
		system("cls");

	} while (flag);*/

	//利用该交互界面该函数会出错，换了其他的也有问题，所以直接这样输出
	caculator_Value();
	//输出前缀与后缀的表达式是为了验证所构造的二叉树是否正确
	system("pause");

	return 0;
}