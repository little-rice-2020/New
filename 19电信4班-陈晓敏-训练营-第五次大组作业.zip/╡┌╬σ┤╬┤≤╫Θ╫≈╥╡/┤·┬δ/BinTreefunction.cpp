#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Binary Tree.h"


//����ն�����T
Status InitBiTree(BiTree T)
{
	T->lchild = T->rchild = NULL;
	T->data = 0;
	return SUCEESS;
}

//�ݻٶ�����T
Status DestroyBiTree(BiTree T) {
	if (T)
	{
		DestroyBiTree(T->lchild);
		DestroyBiTree(T->rchild);
		free(T);
	}
	return SUCEESS;
}


Status CreateBiTree(BiTree T, char* definition)
{
	return SUCEESS;
}

//����������
void CreateBiTree1(BiTree *T)
{
	TElemType ch;
	scanf("%c", &ch);
	if (ch == '#')
		*T = NULL;
	else
	{
		*T = (BiTree)malloc(sizeof(BiTNode));
		if (!*T)
			exit(0);
		(*T)->data = ch;
		CreateBiTree1(&(*T)->lchild);
		CreateBiTree1(&(*T)->rchild);
	}
}

//�����������ڵ�
Status visit(TElemType e)
{
	printf("%c ", e);
	return SUCEESS;
}

//�������
Status PreOrderTraverse(BiTree T, Status (*visit)(TElemType e))
{
	if (T)
	{
		visit(T->data);
		PreOrderTraverse(T->lchild, visit);
		PreOrderTraverse(T->rchild, visit);
	}
	return SUCEESS;
}
//�������
Status InOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	if (T)
	{	
		InOrderTraverse(T->lchild, visit);
		visit(T->data);
		InOrderTraverse(T->rchild, visit);
	}
	return SUCEESS;
}
//�������
Status PostOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	if (T) 
	{
		PostOrderTraverse(T->lchild, visit);
		PostOrderTraverse(T->rchild, visit);
		visit(T->data);
	}	
	return SUCEESS;
}
//�������
Status LevelOrderTraverse(BiTree T, Status(*visit)(TElemType e))
{
	SqQueue Q;
	InitQueue(&Q);
	EnQueue(&Q, T);
	BiTree p;
	while (!QueueEmpty(Q)) {
		DeQueue(&Q, &p);
		visit(p->data);
		if (p->lchild != NULL)
			EnQueue(&Q, p->lchild);
		if (p->rchild != NULL)
			EnQueue(&Q, p->rchild);
	}
	return SUCEESS;
}

//����
void InitQueue(SqQueue * Q) {
	Q->front = Q->rear = 0;
}
int QueueEmpty(SqQueue Q) {
	if (Q.front == Q.rear) return 1;
	return 0;
}
int EnQueue(SqQueue * Q, ElemTypeList e) {
	if ((Q->rear + 1) % MaxSize == Q->front) {
		printf("queue is full!");
		return 0;
	}
	Q->data[Q->rear] = e;
	Q->rear = (Q->rear + 1) % MaxSize;
	return 1;
}
int DeQueue(SqQueue * Q, ElemTypeList * e) {
	if (QueueEmpty(*Q)) return 0;
	*e = Q->data[Q->front];
	Q->front = (Q->front + 1) % MaxSize;
	return 1;
}


