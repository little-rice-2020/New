#ifndef CACULATOR_TREE_H_INCLUDED
#define CACULATOR_TREE_H_INCLUDED

typedef struct BinTreeNode 
{
	char Element;
	struct BinTreeNode* Left;
	struct BinTreeNode* Right;
}BinTreeNode;

BinTreeNode* CreateNode(char ch);
void PreTrversal(BinTreeNode* Tree);
void PostTraversal(BinTreeNode* Tree);
void DestroyTree(BinTreeNode* Tree);
BinTreeNode* create_tree();
int Value(BinTreeNode* T);//������Ķ�������ֵ
int caculator_Value();

#endif
