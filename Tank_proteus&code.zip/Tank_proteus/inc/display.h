#ifndef _DISPLAY_H
#define _DISPLAY_H

//extern uchar time_flg;
extern uchar counter;

void UsartInit();
void time_init();
void refresh();



#endif