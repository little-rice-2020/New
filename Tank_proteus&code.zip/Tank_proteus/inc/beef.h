#ifndef __BEEF_H_
#define __BEEF_H_

#define uchar unsigned char
//���Ŷ��壬�ֱ��尴���ͷ�����������
sbit key_port = P1^0;
sbit key_port5 = P1^5;
sbit SOUNDER = P1^7;


sbit key_port1 = P1^1;
sbit key_port2 = P1^2;
sbit key_port3 = P1^3;
sbit key_port4 = P1^4;
//sbit key_port5 = P1^5;
sbit key_port6 = P1^6;

sbit key_play = P3^2;

void delayms(unsigned int x);
void beef();
void delay_1s();


void music_play();
void delay(uchar p);
void pause();
#endif