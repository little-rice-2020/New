#ifndef _LCDINIT_H
#define _LCDINIT_H

#include "reg52.h"		  
#define uchar unsigned char
#define LCD_CHAR 0x14

sbit cd = P1^0;		/*ͨ��ѡ��*/
sbit rd = P1^1;		/*�������ź�*/
sbit wr = P1^2;		/*д�����ź�*/
sbit error0 = P1^5;  /*������ʾ1*/
sbit error1 = P1^6;  /*������ʾ2*/
sbit error2 = P1^7;  /*������ʾ3*/


//extern char aaa[8];

//void write(uchar x,uchar y ,char aaa[8]);

void lcd();//lcd��ʼ��
void cls(void);

void start(void);

void wirte_cgrom(void);
void delay(int c);//��ʱЧ�������ԣ�һ������
void delay_1s();


void lcd_init(uchar txtstpd1, uchar txtstpd2, uchar txtwid, uchar grhstpd1, uchar grhstpd2, uchar grhwid, uchar cur, uchar mod, uchar sw);
void set_cgram();
void set_cur(char x, char y);
void set_adr(uchar D1, uchar D2);
void set_xy(uchar x, uchar y);
uchar read_one(char way);
void write_one(uchar data1, char way);
void atrd_stop();
void atwr_stop();
void auto_read();
void auto_write();
uchar read_data();
void write_data(uchar data0);
void write_cmd2(uchar data1, uchar data2, uchar cmd);
void write_cmd1(uchar data1, uchar cmd);
void write_cmd0(uchar cmd);
void atwr_enable();
void atrd_enable();
void lcd_enable();
uchar read_state();



#endif