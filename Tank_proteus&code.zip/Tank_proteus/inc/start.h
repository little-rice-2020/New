#ifndef __start_H_
#define __start_H_

#include "reg52.h"
#define uchar unsigned char//���ӵĻ��ᱨ��

extern uchar code map_barrier_num[5];
extern unsigned char code time[60][4];

void time_count(uchar a, uchar b, uchar c, uchar d, char way);
void lcd_start();
void lcd_startgame();//���޸�
void lcd_tankcount();
void lcd_base();
void lcd_basedestroye();

void map1();
void map2();
void map3();
void map4();
void map5();

void score_account_lcd();
void game_after_lcd();
void chooze_game_lcd();
void ranking_list_lcd();
void introduce_game_lcd();//����

void Start_Game();



#endif