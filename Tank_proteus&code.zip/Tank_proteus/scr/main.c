#include "reg52.h"
#include "lcdinit.h"
#include "order.h"
#include "start.h"
#include "tank_function.h"
#include "display.h"

int main()
{	

	lcd();
	UsartInit();

	while(1)
	{

		Start_Game();
	
	}
	return 0;
}

