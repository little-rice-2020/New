//#include "data.h" �ᱨ*** ERROR L104: MULTIPLE PUBLIC DEFINITIONS
#include "tank_function.h"
#include "start.h"
#include "lcdinit.h"
#include "order.h"
#include "i2c.h"

uchar key_statu=0;//ȫ�ֱ������key״̬

//��¼ÿһ�ؿ����ϰ�������
uchar code map_barrier_num[5]={65,55,54,60,71};


//destroy tank num��ʾ
unsigned char code destroy_tank_num[10][2] = 
								{0xd6,0xd7,0xd8,0xd9,0xda,0xdb,
								0xdc,0xdd,0xde,0xdf,0xe0,0xe1,
								0xe2,0xe3,0xe4,0xe5,0xe6,0xe7,
								0xe8,0xe9};	
//time��ʾ
unsigned char code time[60][4] = {

							0xe0,0xe1,0xe8,0xe9,
							0xe0,0xe1,0xe6,0xe7,
							0xe0,0xe1,0xe4,0xe5,
							0xe0,0xe1,0xe2,0xe3,
							0xe0,0xe1,0xe0,0xe1,
							0xe0,0xe1,0xde,0xdf,
							0xe0,0xe1,0xdc,0xdd,
							0xe0,0xe1,0xda,0xdb,
							0xe0,0xe1,0xd8,0xd9,
							0xe0,0xe1,0xd6,0xd7,
							
							0xde,0xdf,0xe8,0xe9,
							0xde,0xdf,0xe6,0xe7,
							0xde,0xdf,0xe4,0xe5,
							0xde,0xdf,0xe2,0xe3,
							0xde,0xdf,0xe0,0xe1,
							0xde,0xdf,0xde,0xdf,
							0xde,0xdf,0xdc,0xdd,
							0xde,0xdf,0xda,0xdb,
							0xde,0xdf,0xd8,0xd9,
							0xde,0xdf,0xd6,0xd7,
							
							0xdc,0xdd,0xe8,0xe9,
							0xdc,0xdd,0xe6,0xe7,
							0xdc,0xdd,0xe4,0xe5,
							0xdc,0xdd,0xe2,0xe3,
							0xdc,0xdd,0xe0,0xe1,
							0xdc,0xdd,0xde,0xdf,
							0xdc,0xdd,0xdc,0xdd,
							0xdc,0xdd,0xda,0xdb,
							0xdc,0xdd,0xd8,0xd9,
							0xdc,0xdd,0xd6,0xd7,
							
							0xda,0xdb,0xe8,0xe9,
							0xda,0xdb,0xe6,0xe7,
							0xda,0xdb,0xe4,0xe5,
							0xda,0xdb,0xe2,0xe3,
							0xda,0xdb,0xe0,0xe1,
							0xda,0xdb,0xde,0xdf,
							0xda,0xdb,0xdc,0xdd,
							0xda,0xdb,0xda,0xdb,
							0xda,0xdb,0xd8,0xd9,
							0xda,0xdb,0xd6,0xd7,
							
							0xd8,0xd9,0xe8,0xe9,
							0xd8,0xd9,0xe6,0xe7,
							0xd8,0xd9,0xe4,0xe5,
							0xd8,0xd9,0xe2,0xe3,
							0xd8,0xd9,0xe0,0xe1,
							0xd8,0xd9,0xde,0xdf,
							0xd8,0xd9,0xdc,0xdd,
							0xd8,0xd9,0xda,0xdb,
							0xd8,0xd9,0xd8,0xd9,
							0xd8,0xd9,0xd6,0xd7,
							
							0xd6,0xd7,0xe8,0xe9,
							0xd6,0xd7,0xe6,0xe7,
							0xd6,0xd7,0xe4,0xe5,
							0xd6,0xd7,0xe2,0xe3,
							0xd6,0xd7,0xe0,0xe1,
							0xd6,0xd7,0xde,0xdf,
							0xd6,0xd7,0xdc,0xdd,
							0xd6,0xd7,0xda,0xdb,
							0xd6,0xd7,0xd8,0xd9,
							0xd6,0xd7,0xd6,0xd7	};

//����
void introduce_game_lcd()
{

	 /*1*/
	set_xy(14,14);
	write_one(0xd8,INC_WR);
	set_xy(14,15);
	write_one(0xd9,INC_WR);
	//��
	set_xy(16, 14);
	write_one(0xee, INC_WR);
	write_one(0xef, INC_WR);
	set_xy(16, 15);
	write_one(0xf0, INC_WR);
	write_one(0xf1, INC_WR);
	//��
	set_xy(18, 14);
	write_one(0xf2, INC_WR);
	write_one(0xf3, INC_WR);
	set_xy(18, 15);
	write_one(0xf4, INC_WR);
	write_one(0xf5, INC_WR);	
}

void lcd_start()
{
 	//lcd();//Һ����ʼ���������Զ����ַ�����ROM��
	/*1*/
	set_xy(6,3);
	write_one(0xd8,INC_WR);
	set_xy(6,4);
	write_one(0xd9,INC_WR);
  	/*˵��*/
	set_xy(8,3);
	write_one(0x80,INC_WR);
	write_one(0x81,INC_WR);
	set_xy(8,4);
	write_one(0x82,INC_WR);
	write_one(0x83,INC_WR);
	set_xy(10,3);
	write_one(0x84,INC_WR);
	write_one(0x85,INC_WR);
	set_xy(10,4);
	write_one(0x86,INC_WR);
	write_one(0x87,INC_WR);
	/*2*/
	set_xy(6,6);
	write_one(0xda,INC_WR);
	set_xy(6,7);
	write_one(0xdb,INC_WR);
	/*��ʼ*/
	set_xy(8,6);
	write_one(0x88,INC_WR);
	write_one(0x89,INC_WR);
	set_xy(8,7);
	write_one(0x8a,INC_WR);
	write_one(0x8b,INC_WR);
	set_xy(10,6);
	write_one(0x8c,INC_WR);
	write_one(0x8d,INC_WR);
	set_xy(10,7);
	write_one(0x8e,INC_WR);
	write_one(0x8f,INC_WR);
	/*3*/
	set_xy(5,9);
	write_one(0xdc,INC_WR);
	set_xy(5,10);
	write_one(0xdd,INC_WR);
	/*���а�*/
	set_xy(7,9);
	write_one(0x90,INC_WR);
	write_one(0x91,INC_WR);
	set_xy(7,10);
	write_one(0x92,INC_WR);
	write_one(0x93,INC_WR);
	set_xy(9,9);
	write_one(0x94,INC_WR);
	write_one(0x95,INC_WR);
	set_xy(9,10);
	write_one(0x96,INC_WR);
	write_one(0x97,INC_WR);
	set_xy(11,9);
	write_one(0x98,INC_WR);
	write_one(0x99,INC_WR);
	set_xy(11,10);
	write_one(0x9a,INC_WR);
	write_one(0x9b,INC_WR);



}
/*
//lcd��Ϸ������ʾ
void lcd_startgame()
{
	//����
	set_xy(7,14);
	write_one(0x9c,INC_WR);
	write_one(0x9d,INC_WR);
	set_xy(7,15);
	write_one(0x9e,INC_WR);
	write_one(0x9f,INC_WR);
	//ը�ٻ���
	set_xy(7,14);
	write_one(0xa0,INC_WR);
	write_one(0xa1,INC_WR);
	set_xy(7,15);
	write_one(0xa2,INC_WR);
	write_one(0xa3,INC_WR);

	//ʱ��
	set_xy(17,14);
	write_one(0xd8,INC_WR);
	write_one(0xda,INC_WR);
	set_xy(17,15);
	write_one(0xd9,INC_WR);
	write_one(0xdb,INC_WR);

} */
/*ʱ����ʾ*/
void time_count(uchar a,uchar b,uchar c,uchar d,char way)
{
	set_xy(17,1);
	write_one(a,way);	//  0xd8
	write_one(c,way);	//	0xda
	set_xy(17,2);
	write_one(b,way);  //0xd9
	write_one(d,way);  //0xdb
	delay_1s();

}
void lcd_base()
{	
	/*player ��ʼλ��*/
	set_xy(5,15);
	write_one(0xa6,INC_WR);

	/*����*/
	set_xy(7,15);
	write_one(0x9c,INC_WR);
	
	set_xy(6,15);
	write_one(0xa7,INC_WR);
	set_xy(8,15);
	write_one(0xa7,INC_WR);
	set_xy(6,14);
	write_one(0xa7,INC_WR);
	write_one(0xa7,INC_WR);
	write_one(0xa7,INC_WR);
}
/*
void lcd_basedestroye()
{
	//ը�ٻ���
	set_xy(7,15);
	write_one(0xa0,INC_WR);
	
	set_xy(6,15);
	write_one(0xa7,INC_WR);
	set_xy(8,15);
	write_one(0xa7,INC_WR);
	set_xy(6,14);
	write_one(0xa7,INC_WR);
	write_one(0xa7,INC_WR);
	write_one(0xa7,INC_WR);
}*/
/*��ʾ̹������*/
void lcd_tankcount()
{
	set_xy(17,4); 
	write_one(0xa6,INC_WR);
	set_xy(19,4);
	write_one(0xa6,INC_WR);

	set_xy(17,6); 
	write_one(0xa6,INC_WR);
	set_xy(19,6);
	write_one(0xa6,INC_WR);

	set_xy(17,8); 
	write_one(0xa6,INC_WR);
	set_xy(19,8);
	write_one(0xa6,INC_WR);

	set_xy(17,10); 
	write_one(0xa6,INC_WR);
	set_xy(19,10);
	write_one(0xa6,INC_WR);
}



void map1()
{
	uchar i;

	lcd_base();
	lcd_tankcount();

	for(i=1;i<15;i++)
 	{ 
		set_xy(i,1);
 	 write_one(0xa7,INC_WR);
 	}//14
	for(i=4;i<13;i++)
 	{ 
		set_xy(1,i);
 	 write_one(0xa7,INC_WR);
 	}//9
	for(i=4;i<12;i++)
 	{ 
		set_xy(4,i);
 	 write_one(0xa7,INC_WR);
 	}//9
	set_xy(4,12);
 	 write_one(0xf6,INC_WR);

	 for(i=4;i<13;i++)
 	{ 
		set_xy(11,i);
 	 write_one(0xa7,INC_WR);
 	}//9
	 for(i=4;i<13;i++)
 	{ 
		set_xy(14,i);
 	 write_one(0xa7,INC_WR);

 	}//9
	

	 //��ǽ
	 set_xy(7,6);
 	 write_one(0xa5,INC_WR);
	 set_xy(8,6);
 	 write_one(0xa5,INC_WR);
	 set_xy(7,7);
 	 write_one(0xa5,INC_WR);
	 set_xy(8,7);
 	 write_one(0xa5,INC_WR);//4

	  for(i=5;i<11;i++)
 	{ 
		set_xy(i,12);
 	 write_one(0xa7,INC_WR);//6
 	}
/*��ʾ�ؿ�*/
	 set_xy(15,14);
 	 write_one(0xd2,INC_WR);
 	 write_one(0xd3,INC_WR);
	 set_xy(15,15);
 	 write_one(0xd4,INC_WR);
	 write_one(0xd5,INC_WR);

	 /*1*/
	set_xy(17,14);
	write_one(0xd8,INC_WR);
	set_xy(17,15);
	write_one(0xd9,INC_WR);

	set_xy(18,14);
 	 write_one(0xce,INC_WR);
 	 write_one(0xcf,INC_WR);
	 set_xy(18,15);
 	 write_one(0xd0,INC_WR);
	 write_one(0xd1,INC_WR);


}
void map2()
{
	uchar i;

	lcd_base();
	lcd_tankcount();

	for(i=1;i<7;i++)
 	{ 
		set_xy(i,1);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=9;i<15;i++)
 	{ 
		set_xy(i,1);
 	 write_one(0xa7,INC_WR);
 	}


	for(i=2;i<8;i++)
 	{ 
		set_xy(3,i);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=2;i<8;i++)
 	{ 
		set_xy(4,i);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=2;i<8;i++)
 	{ 
		set_xy(11,i);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=2;i<8;i++)
 	{ 
		set_xy(12,i);
 	 write_one(0xa7,INC_WR);
 	}

	 set_xy(5,9);
 	 write_one(0xa7,INC_WR);
	 set_xy(6,9);
 	 write_one(0x00,INC_WR);
	 set_xy(7,9);
 	 write_one(0xa7,INC_WR);
	 set_xy(8,9);
 	 write_one(0x00,INC_WR);
	 set_xy(9,9);
 	 write_one(0xa7,INC_WR);
	 set_xy(10,9);
 	 write_one(0x00,INC_WR);

	 set_xy(5,10);
 	 write_one(0x00,INC_WR);
	 set_xy(6,10);
 	 write_one(0xa7,INC_WR);
	 set_xy(7,10);
 	 write_one(0x00,INC_WR);
	 set_xy(8,10);
 	 write_one(0xa7,INC_WR);
	 set_xy(9,10);
 	 write_one(0x00,INC_WR);
	 set_xy(10,10);
 	 write_one(0xa7,INC_WR);

/*��ǽ*/
	 set_xy(7,6);
 	 write_one(0xa5,INC_WR);
	 set_xy(8,6);
 	 write_one(0xa5,INC_WR);
	 set_xy(7,7);
 	 write_one(0xa5,INC_WR);
	 set_xy(8,7);
 	 write_one(0xa5,INC_WR);
/*��ǽ*/
	 set_xy(0,14);
 	 write_one(0xa5,INC_WR);
	 set_xy(1,14);
 	 write_one(0xa5,INC_WR);
	 set_xy(0,15);
 	 write_one(0xa5,INC_WR);
	 set_xy(1,15);
 	 write_one(0xa5,INC_WR);
	 
/*��ʾ�ؿ�*/
	 set_xy(15,14);
 	 write_one(0xd2,INC_WR);
 	 write_one(0xd3,INC_WR);
	 set_xy(15,15);
 	 write_one(0xd4,INC_WR);
	 write_one(0xd5,INC_WR);

	 /*2*/
	set_xy(17,14);
	write_one(0xda,INC_WR);
	set_xy(17,15);
	write_one(0xdb,INC_WR);

	 set_xy(18,14);
 	 write_one(0xce,INC_WR);
 	 write_one(0xcf,INC_WR);
	 set_xy(18,15);
 	 write_one(0xd0,INC_WR);
	 write_one(0xd1,INC_WR);
  
   
}

void map3()
{
	uchar i;
	lcd_base();
	lcd_tankcount();


	for(i=3;i<13;i++)
 	{ 
		set_xy(i,3);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=4;i<11;i++)
 	{ 
		set_xy(7,i);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
 	}
	 for(i=3;i<13;i++)
 	{ 
		set_xy(i,11);
 	 write_one(0xa7,INC_WR);
 	}


	 set_xy(13,6);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 set_xy(14,8);
 	 write_one(0xa7,INC_WR);
	 set_xy(14,9);
	 write_one(0xa7,INC_WR);


/*�����ϰ�*/
	set_xy(0,7);
 	 write_one(0xa7,INC_WR);
	set_xy(0,8);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);

	 set_xy(13,0);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 set_xy(14,1);
	 write_one(0xa7,INC_WR);

/*�����ϰ�*/
	set_xy(1,14);
 	 write_one(0xa7,INC_WR);
	set_xy(0,15);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);

/*��ǽ*/
	 set_xy(0,0);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(0,1);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
/*��ǽ*/
	 set_xy(13,14);
 	 write_one(0xa5,INC_WR);
	 write_one(0xa5,INC_WR);
	 set_xy(13,15);
 	 write_one(0xa5,INC_WR);
	 write_one(0xa5,INC_WR);
	 
/*��ʾ�ؿ�*/
	 set_xy(15,14);
 	 write_one(0xd2,INC_WR);
 	 write_one(0xd3,INC_WR);
	 set_xy(15,15);
 	 write_one(0xd4,INC_WR);
	 write_one(0xd5,INC_WR);

	 /*3*/
	set_xy(17,14);
	write_one(0xdc,INC_WR);
	set_xy(17,15);
	write_one(0xdd,INC_WR);

	 set_xy(18,14);
 	 write_one(0xce,INC_WR);
 	 write_one(0xcf,INC_WR);
	 set_xy(18,15);
 	 write_one(0xd0,INC_WR);
	 write_one(0xd1,INC_WR);
  

}

void map4()
{
	uchar i;
	lcd_base();
	lcd_tankcount();


	for(i=1;i<6;i++)
 	{ 
		set_xy(2,i);
 	 write_one(0xa7,INC_WR);
 	}	
	 set_xy(3,3);
 	 write_one(0xa7,INC_WR);
	for(i=1;i<6;i++)
 	{ 
		set_xy(4,i);
 	 write_one(0xa7,INC_WR);
 	}


	for(i=1;i<6;i++)
 	{ 
		set_xy(11,i);
 	 write_one(0xa7,INC_WR);
 	}
	set_xy(12,3);
 	 write_one(0xa7,INC_WR);
	for(i=1;i<6;i++)
 	{ 
		set_xy(13,i);
 	 write_one(0xa7,INC_WR);
 	}

	for(i=8;i<13;i++)
 	{ 
		set_xy(3,i);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=4;i<12;i++)
 	{ 
		set_xy(i,10);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=8;i<13;i++)
 	{ 
		set_xy(12,i);
 	 write_one(0xa7,INC_WR);
 	}


/*�����ϰ�*/
	set_xy(14,13);
 	 write_one(0xa7,INC_WR);
	set_xy(13,14);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);

/*�����ϰ�*/
	set_xy(0,9);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	set_xy(0,10);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 

/*��ǽ*/
	 set_xy(7,6);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(7,7);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);

	 set_xy(0,15);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(13,15);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 
/*��ʾ�ؿ�*/
	 set_xy(15,14);
 	 write_one(0xd2,INC_WR);
 	 write_one(0xd3,INC_WR);
	 set_xy(15,15);
 	 write_one(0xd4,INC_WR);
	 write_one(0xd5,INC_WR);

	 /*4*/
	set_xy(17,14);
	write_one(0xde,INC_WR);
	set_xy(17,15);
	write_one(0xdf,INC_WR);

	 set_xy(18,14);
 	 write_one(0xce,INC_WR);
 	 write_one(0xcf,INC_WR);
	 set_xy(18,15);
 	 write_one(0xd0,INC_WR);
	 write_one(0xd1,INC_WR);
  
  

}

void map5()
{
	uchar i;
	lcd_base();
	lcd_tankcount();


	for(i=3;i<13;i++)
 	{ 
		set_xy(i,2);
 	 write_one(0xa7,INC_WR);
 	}	 
	for(i=5;i<11;i++)
 	{ 
		set_xy(i,1);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=7;i<9;i++)
 	{ 
		set_xy(i,0);
 	 write_one(0xa7,INC_WR);
 	}
	
	set_xy(7,6);
 	 write_one(0xa7,INC_WR);
	set_xy(7,7);
 	 write_one(0xa7,INC_WR);
	 set_xy(7,8);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);	
 
	 set_xy(4,10);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 set_xy(10,10);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
 	
	for(i=4;i<12;i++)
 	{ 
		set_xy(i,11);
 	 write_one(0xa7,INC_WR);
 	}

	 set_xy(2,13);
 	 write_one(0xa7,INC_WR);
	 set_xy(1,14);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 set_xy(0,15);
 	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);
	 write_one(0xa7,INC_WR);


/*�����ϰ�*/
	for(i=4;i<8;i++)
 	{ 
		set_xy(13,i);
 	 write_one(0xa7,INC_WR);
 	}
	for(i=8;i<10;i++)
 	{ 
		set_xy(12,i);
 	 write_one(0xa7,INC_WR);
 	}

/*ʮ���ϰ�*/
	set_xy(1,7);
 	 write_one(0xa7,INC_WR);
	set_xy(0,8);
 	write_one(0xa7,INC_WR);	
	write_one(0xa7,INC_WR);
	write_one(0xa7,INC_WR);
	set_xy(1,9);
 	 write_one(0xa7,INC_WR); 

/*��ǽ*/
	 set_xy(4,4);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(4,5);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);

	 set_xy(10,4);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(10,5);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 
	 set_xy(13,14);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
	 set_xy(13,15);
 	 write_one(0xa5,INC_WR);
 	 write_one(0xa5,INC_WR);
/*��ʾ�ؿ�*/
	 set_xy(15,14);
 	 write_one(0xd2,INC_WR);
 	 write_one(0xd3,INC_WR);
	 set_xy(15,15);
 	 write_one(0xd4,INC_WR);
	 write_one(0xd5,INC_WR);

	 /*5*/
	set_xy(17,14);
	write_one(0xe0,INC_WR);
	set_xy(17,15);
	write_one(0xe1,INC_WR);

	 set_xy(18,14);
 	 write_one(0xce,INC_WR);
 	 write_one(0xcf,INC_WR);
	 set_xy(18,15);
 	 write_one(0xd0,INC_WR);
	 write_one(0xd1,INC_WR);
  
}

void score_account_lcd()
{
	uchar i;

	 /*tank*/
	 set_xy(4,1);
 	 write_one(0xa6,INC_WR);
	 write_one(0xa6,INC_WR);
	 set_xy(4,2);
	 write_one(0xa6,INC_WR);
	 write_one(0xa6,INC_WR);
	  /* * */
	 set_xy(6,1);
 	 write_one(0xb1,INC_WR);
	 write_one(0xb2,INC_WR);
	 set_xy(6,2);
	 write_one(0xb3,INC_WR);
	 write_one(0xb4,INC_WR);
	 /*account*/
	 set_xy(8,1);
 	 write_one(destroy_tank_num[para.destroye_num][0],INC_WR);
	 set_xy(8,2);
 	 write_one(destroy_tank_num[para.destroye_num][1],INC_WR);
	/*+*/
	 set_xy(10,1);
 	 write_one(0xa9,INC_WR);
 	 write_one(0xaa,INC_WR);
	 set_xy(10,2);
 	 write_one(0xab,INC_WR);
 	 write_one(0xac,INC_WR);
	 /*tank score*/
	 set_xy(13,1);
 	 write_one(destroy_tank_num[para.destroye_num][0],INC_WR);
	 set_xy(13,2);
 	 write_one(destroy_tank_num[para.destroye_num][1],INC_WR);
	 set_xy(14,1);
 	 write_one(0xd6,INC_WR);
	 set_xy(14,2);
 	 write_one(0xd7,INC_WR);


	 /*+*/
	 set_xy(6,9);
 	 write_one(0xa9,INC_WR);
 	 write_one(0xaa,INC_WR);
	 set_xy(6,10);
 	 write_one(0xab,INC_WR);
 	 write_one(0xac,INC_WR);
	 /*time score*/
	if(para.time_account<30)
	 {
		 set_xy(10,9);
	 	 write_one(0xda,INC_WR);
		 set_xy(10,10);
	 	 write_one(0xdb,INC_WR);
		 set_xy(11,9);
	 	 write_one(0xd6,INC_WR);
		 set_xy(11,10);
	 	 write_one(0xd7,INC_WR);
	 }
	 else
	 {
		 set_xy(10,9);
	 	 write_one(0xd8,INC_WR);
		 set_xy(10,10);
	 	 write_one(0xd9,INC_WR);
		 set_xy(11,9);
	 	 write_one(0xd6,INC_WR);
		 set_xy(11,10);
	 	 write_one(0xd7,INC_WR);
	 }
	 /*S*/
	 set_xy(13,9);
 	 write_one(0xb5,INC_WR);
	 set_xy(13,10);
 	 write_one(0xb6,INC_WR);

	/*ALL*/
	 set_xy(6,13);
 	 write_one(0xad,INC_WR);
 	 write_one(0xae,INC_WR);
	 set_xy(6,14);
 	 write_one(0xaf,INC_WR);
 	 write_one(0xb0,INC_WR);	
 	 /*score*/
	 if(para.time_account<30)
	 {
		 set_xy(10,13);
	 	 write_one(destroy_tank_num[para.destroye_num+2][0],INC_WR);
		 set_xy(10,14);
	 	 write_one(destroy_tank_num[para.destroye_num+2][1],INC_WR);
		 set_xy(11,13);
	 	 write_one(0xd6,INC_WR);
		 set_xy(11,14);
	 	 write_one(0xd7,INC_WR);

		 para.all_score=(para.destroye_num+2)*10;
	 }
	 else
	 {
		 set_xy(10,13);
	 	 write_one(destroy_tank_num[para.destroye_num+1][0],INC_WR);
		 set_xy(10,14);
	 	 write_one(destroy_tank_num[para.destroye_num+1][1],INC_WR);
		 set_xy(11,13);
	 	 write_one(0xd6,INC_WR);
		 set_xy(11,14);
	 	 write_one(0xd7,INC_WR);

		 para.all_score=(para.destroye_num+1)*10;
	 }

	 //�����ݱ����eeprom��
	 At24c02Write(para.guan_qia,para.all_score);

	 //  At24c02Write(para.guan_qia,0);
	 //������ʾ10s
	 i=10;
	 while(i--)
	 {
	 	delay_1s();
	 }

	 cls();

}
void game_after_lcd()
{
	 //lcd();//Һ����ʼ���������Զ����ַ�����ROM��
	/*1*/
	set_xy(4,3);
	write_one(0xd8,INC_WR);
	set_xy(4,4);
	write_one(0xd9,INC_WR);
  	/*��ʼ����*/
	set_xy(6,3);
	write_one(0x88,INC_WR);
	write_one(0x89,INC_WR);
	set_xy(6,4);
	write_one(0x8a,INC_WR);
	write_one(0x8b,INC_WR);
	set_xy(8,3);
	write_one(0x8c,INC_WR);
	write_one(0x8d,INC_WR);
	set_xy(8,4);
	write_one(0x8e,INC_WR);
	write_one(0x8f,INC_WR);

	set_xy(10,3);
	write_one(0xa8,INC_WR);
	write_one(0xb7,INC_WR);
	set_xy(10,4);
	write_one(0xb8,INC_WR);
	write_one(0xb9,INC_WR);
	set_xy(12,3);
	write_one(0xba,INC_WR);
	write_one(0xbb,INC_WR);
	set_xy(12,4);
	write_one(0xbc,INC_WR);
	write_one(0xbd,INC_WR);

	/*2*/
	set_xy(5,6);
	write_one(0xda,INC_WR);
	set_xy(5,7);
	write_one(0xdb,INC_WR);
	/*��һ��*/
	set_xy(7,6);
	write_one(0xbe,INC_WR);
	write_one(0xbf,INC_WR);
	set_xy(7,7);
	write_one(0xc0,INC_WR);
	write_one(0xc1,INC_WR);

	set_xy(9,6);
	write_one(0xc2,INC_WR);
	write_one(0xc3,INC_WR);
	set_xy(9,7);
	write_one(0xc4,INC_WR);
	write_one(0xc5,INC_WR);

	set_xy(11,6);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(11,7);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);
	/*3*/
	set_xy(4,9);
	write_one(0xdc,INC_WR);
	set_xy(4,10);
	write_one(0xdd,INC_WR);
	/*ѡ��ؿ�*/
	set_xy(6,9);
	write_one(0xc6,INC_WR);
	write_one(0xc7,INC_WR);
	set_xy(6,10);
	write_one(0xc8,INC_WR);
	write_one(0xc9,INC_WR);
	set_xy(8,9);
	write_one(0xca,INC_WR);
	write_one(0xcb,INC_WR);
	set_xy(8,10);
	write_one(0xcc,INC_WR);
	write_one(0xcd,INC_WR);

	set_xy(10,9);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(10,10);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);
	set_xy(12,9);
	write_one(0xea,INC_WR);
	write_one(0xeb,INC_WR);
	set_xy(12,10);
	write_one(0xec,INC_WR);
	write_one(0xed,INC_WR);
}

void chooze_game_lcd()
{	
	/*1*/
	set_xy(0,0);
	write_one(0xd8,INC_WR);
	set_xy(0,1);
	write_one(0xd9,INC_WR);
	/*��һ��*/
	set_xy(2,0);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,1);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,0);
	write_one(0xd8,INC_WR);
	set_xy(5,1);
	write_one(0xd9,INC_WR);

	set_xy(6,0);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,1);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);

	/*2*/
	set_xy(0,2);
	write_one(0xda,INC_WR);
	set_xy(0,3);
	write_one(0xdb,INC_WR);
	/*��2��*/
	set_xy(2,2);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,3);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,2);
	write_one(0xda,INC_WR);
	set_xy(5,3);
	write_one(0xdb,INC_WR);

	set_xy(6,2);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,3);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);

	/*3*/
	set_xy(0,4);
	write_one(0xdc,INC_WR);
	set_xy(0,5);
	write_one(0xdd,INC_WR);
	/*��3��*/
	set_xy(2,4);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,5);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,4);
	write_one(0xdc,INC_WR);
	set_xy(5,5);
	write_one(0xdd,INC_WR);

	set_xy(6,4);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,5);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);


	/*4*/
	set_xy(0,6);
	write_one(0xde,INC_WR);
	set_xy(0,7);
	write_one(0xdf,INC_WR);
	/*��4��*/
	set_xy(2,6);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,7);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,6);
	write_one(0xde,INC_WR);
	set_xy(5,7);
	write_one(0xdf,INC_WR);

	set_xy(6,6);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,7);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);


	/*5*/
	set_xy(0,8);
	write_one(0xe0,INC_WR);
	set_xy(0,9);
	write_one(0xe1,INC_WR);
	/*��5��*/
	set_xy(2,8);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,9);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,8);
	write_one(0xe0,INC_WR);
	set_xy(5,9);
	write_one(0xe1,INC_WR);

	set_xy(6,8);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,9);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);
}

void ranking_list_lcd()
{	
	 uchar score, guan;
	 uchar i=0;

	set_xy(18,2);
	write_one(0x90,INC_WR);
	write_one(0x91,INC_WR);
	set_xy(18,3);
	write_one(0x92,INC_WR);
	write_one(0x93,INC_WR);

	set_xy(18,6);
	write_one(0x94,INC_WR);
	write_one(0x95,INC_WR);
	set_xy(18,7);
	write_one(0x96,INC_WR);
	write_one(0x97,INC_WR);

	set_xy(18,10);
	write_one(0x98,INC_WR);
	write_one(0x99,INC_WR);
	set_xy(18,11);
	write_one(0x9a,INC_WR);
	write_one(0x9b,INC_WR);

	/*1*/
	set_xy(0,0);
	write_one(0xd8,INC_WR);
	set_xy(0,1);
	write_one(0xd9,INC_WR);
	/*��һ��*/
	set_xy(2,0);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,1);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,0);
	write_one(0xd8,INC_WR);
	set_xy(5,1);
	write_one(0xd9,INC_WR);

	set_xy(6,0);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,1);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);

	/*2*/
	set_xy(0,2);
	write_one(0xda,INC_WR);
	set_xy(0,3);
	write_one(0xdb,INC_WR);
	/*��2��*/
	set_xy(2,2);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,3);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,2);
	write_one(0xda,INC_WR);
	set_xy(5,3);
	write_one(0xdb,INC_WR);

	set_xy(6,2);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,3);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);

	/*3*/
	set_xy(0,4);
	write_one(0xdc,INC_WR);
	set_xy(0,5);
	write_one(0xdd,INC_WR);
	/*��3��*/
	set_xy(2,4);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,5);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,4);
	write_one(0xdc,INC_WR);
	set_xy(5,5);
	write_one(0xdd,INC_WR);

	set_xy(6,4);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,5);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);


	/*4*/
	set_xy(0,6);
	write_one(0xde,INC_WR);
	set_xy(0,7);
	write_one(0xdf,INC_WR);
	/*��4��*/
	set_xy(2,6);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,7);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,6);
	write_one(0xde,INC_WR);
	set_xy(5,7);
	write_one(0xdf,INC_WR);

	set_xy(6,6);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,7);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);


	/*5*/
	set_xy(0,8);
	write_one(0xe0,INC_WR);
	set_xy(0,9);
	write_one(0xe1,INC_WR);
	/*��5��*/
	set_xy(2,8);
	write_one(0xd2,INC_WR);
	write_one(0xd3,INC_WR);
	set_xy(2,9);
	write_one(0xd4,INC_WR);
	write_one(0xd5,INC_WR);

	set_xy(5,8);
	write_one(0xe0,INC_WR);
	set_xy(5,9);
	write_one(0xe1,INC_WR);

	set_xy(6,8);
	write_one(0xce,INC_WR);
	write_one(0xcf,INC_WR);
	set_xy(6,9);
	write_one(0xd0,INC_WR);
	write_one(0xd1,INC_WR);


	
	for(guan=1;guan<=5;guan++)
	{
		score=At24c02Read(guan);
		set_xy(10,i);
		write_one(destroy_tank_num[score/10][0], INC_WR);
		set_xy(10,i+1);
		write_one(destroy_tank_num[score/10][1], INC_WR);

		set_xy(11,i);
		write_one(0xd6, INC_WR);
		set_xy(11,i+1);
		write_one(0xd7, INC_WR);

		i=i+2;
	}
}









