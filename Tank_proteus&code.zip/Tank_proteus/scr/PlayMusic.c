#include <REG52.H>
#include "SoundPlay.h"


