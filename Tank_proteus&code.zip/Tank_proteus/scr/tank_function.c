#include "tank_function.h"
#include "lcdinit.h"
#include "order.h"
#include "start.h"
#include "display.h"

#include<stdlib.h>
#include<string.h>

#define a 1//118
#define b 1
#define c 1
#define key_score P0

		  
volatile struct Para para;
//uchar code Current_Loc[66][3];
uchar key_status=0;
uchar Cheak_wall_flg = 0 ;
uchar flag = 1;
uchar time_flg;
Tank phead1;
Tank phead2;
Tank phead3;

uchar Tank_zidan_3 = 0;
uchar Current_Loc_Sit[9] = {0};	 //����Խ��������벻�������

uchar code Current_Loc1[65][3]=	{
									8,15,2,  6,15,2,   6,14,2,  7,14,2,  8,14,2,
							        1,1,2,   2,1,2,    3,1,2,   4,1,2,   5,1,2, 
							        6,1,2,   7,1,2,    8,1,2,   9,1,2,   10,1,2, 
							        11,1,2,  12,1,2,   13,1,2,  14,1,2,  1,4,2,  
							        1,5,2,   1,6,2,    1,7,2,   1,8,2,   1,9,2,  
							        1,10,2,  1,11,2,   1,12,2,  4,4,2,   4,5,2, 
							        4,6,2,   4,7,2,    4,8,2,   4,9,2,   4,10,2,
							        4,11,2,  4,12,3,   11,4,2,  11,5,2,  11,6,2, 
							        11,7,2,  11,8,2,   11,9,2,  11,10,2, 11,11,2,
							        11,12,2, 14,4,2,   14,5,2,  14,6,2,  14,7,2,
							        14,8,2,  14,9,2,   14,10,2, 14,11,2, 14,12,2,
	        						7,6,1,   8,6,1,    7,7,1,   8,7,1,   5,12,2, 
									6,12,2,  7,12,2,   8,12,2,  9,12,2,  10,12,2,
								 };

uchar code Current_Loc2[55][3]={6 ,15,2  , 8 ,15,2 , 6 ,14,2, 
								7 ,14,2  , 8 ,14,2 , 1 ,1 ,2,
								2 ,1 ,2  , 3 ,1 ,2 , 4 ,1 ,2,
								5 ,1 ,2  , 6 ,1 ,2 , 9 ,1 ,2,
								10,1 ,2  , 11,1 ,2 , 12,1 ,2,
								13,1 ,2  , 14,1 ,2 , 3 ,2 ,2,
								3 ,3 ,2  , 3 ,4 ,2 , 3 ,5 ,2,
								3 ,6 ,2  , 3 ,7 ,2 , 4 ,2 ,2,
								4 ,3 ,2  , 4 ,4 ,2 , 4 ,5 ,2,
								4 ,6 ,2  , 4 ,7 ,2 , 11,2 ,2,
								11,3 ,2  , 11,4 ,2 , 11,5 ,2,
								11,6 ,2  , 11,7 ,2 , 12,2 ,2,
								12,3 ,2  , 12,4 ,2 , 12,5 ,2,
								12,6 ,2  , 12,7 ,2 , 5 ,9 ,2,
								7 ,9 ,2  , 9 ,9 ,2 , 6 ,10,2,
								8 ,10,2  , 0 ,10,2 , 7 ,6 ,1,
								8 ,6 ,1  , 7 ,7 ,1 , 8 ,7 ,1,
								0 ,14,1  , 1 ,14,1 , 0 ,15,1,
								1 ,15,1  } ;


uchar code Current_Loc3[54][3]={6,15,2   , 8 ,15,2 , 6,14,2 ,    
								7,14,2   , 8 ,14,2 , 3,3,2,
								4,3,2    , 5 ,3 ,2 , 6,3,2,
								7,3,2    , 8 ,3 ,2 , 9,3,2,
								10,3,2   , 11,3 ,2 , 12,3,2,
								7 ,4,2   , 7 ,5 ,2 , 7,6,2,
								7,7,2    , 7 ,8 ,2 , 7,9,2,
								7,10,2   , 3 ,11,2 , 4,11,2,
								5,11,2,  6 ,11,2,7,11,2,
								8,11,2,  9,11,2, 10,11,2,
								11,11,2, 12,11,2, 13,6,2,
								14,6,2 , 14,8,2 , 14,9,2,
								0,7,2 , 0,8,2 , 1,8,2,
								13,0,2 , 14,0,2 , 14,1,2,
								1,14,2 , 0,15,2 , 1,15,2,
								2,15,2 , 0,0,1 , 1,0,1 , 
								0,1,1 , 1,1,1 , 13,14,1 , 
								14,14,1 , 13,15,1 , 14,15,1};

uchar code Current_Loc4[60][3]={6,15,2  , 8,15,2 , 6,14,2 , 
								7,14,2  , 8,14,2 ,  2,1,2 ,
								2,2,2 , 2,3,2 , 2,4,2 ,
								2,5,2 , 3,3,2 , 4,1,2 ,
								4,2,2 , 4,3,2 , 4,4,2 ,
								4,5,2 , 11,1,2 , 11,2,2 ,
								11,3,2 , 11,4,2 , 11,5,2 ,
								12,3,2 ,  13,1,2 , 13,2,2 ,
								13,3,2 , 13,4,2 , 13,5,2 ,
								3,8,2 , 3,9,2 , 3,10,2 ,
								3,11,2 , 3,12,2 , 4,10,2 ,
								5,10,2 , 6,10,2 , 7,10,2 ,
								8,10,2 , 9,10,2 , 10,10,2 ,
								11,10,2 , 12,8,2 , 12,9,2 ,
								12,10,2 , 12,11,2 , 12,12,2 ,
								14,13,2 , 13,14,2 , 14,14,2 ,
								0,9,2 , 1,9,2 , 0,10,2 ,
								1,10,2 , 7,6,1 , 8,6,1 , 
								7,7,1 , 8,7,1 , 0,15,1 , 
								1,15,1 , 13,15,1 , 14,15,1};
									  
uchar code Current_Loc5[71][3]={6,15,2  , 8,15,2 , 6,14,2 ,  
								7,14,2  , 8,14,2 ,  3,2,2 ,
								4,2,2 , 5,2,2 , 6,2,2 , 
								7,2,2 , 8,2,2 , 9,2,2 ,
								10,2,2 , 11,2,2 , 12,2,2 ,
								5,1,2 , 6,1,2 , 7,1,2 ,
								8,1,2 , 9,1,2 , 10,1,2 ,
								7,0,2 , 8,0,2 , 7,6,2 ,
								7,7,2 , 7,8,2 , 8,8,2 ,
								4,10,2 , 5,10,2 , 10,10,2 ,
								11,10,2 ,  4,11,2 , 5,11,2 ,
								6,11,2 , 7,11,2 , 8,11,2 ,
								9,11,2 , 10,11,2 , 11,11,2 , 
								2,13,2 , 1,14,2 , 2,14,2  ,
								3,14,2 , 0,15,2 , 1,15,2 ,
								2, 15,2 , 3,15,2 , 4,15,2,
								13,4,2 , 13,5,2 , 13,6,2 ,
								13,7,2 , 12,8,2 , 12,9,2 ,
								1,7,2 , 0,8,2 , 1,8,2 ,
								2,8,2 , 1,9,2 , 4,4,1 ,
								5 ,4 ,1 , 4,5,1 , 5,5,1 ,
								10,4,1 , 11,4,1 , 10,5,1 ,
								11,5,1 , 13,14,1 , 14,14,1 ,
								13,15,1 , 14,15,1 };

uchar find_x(uchar guan, uchar i)
{
	 switch(guan)
	 {
	 	 case 1: return Current_Loc1[i][0];
		 break;

		 case 2: return Current_Loc2[i][0];
		 break;

		 case 3: return Current_Loc3[i][0];
		 break;

		 case 4: return Current_Loc4[i][0];
		 break;

		 case 5: return Current_Loc5[i][0];
		 break;	 
	 }

	 return 0; 
}
uchar find_y(uchar guan, uchar i)
{
	 switch(guan)
	 {
	 	 case 1: return Current_Loc1[i][1];	 break;

		 case 2: return Current_Loc2[i][1];	 break;

		 case 3: return Current_Loc3[i][1];	 break;

		 case 4: return Current_Loc4[i][1];	break;

		 case 5: return Current_Loc5[i][1];	break;	 
	 }

	 return 0; 
}
uchar find_q(uchar guan, uchar i)
{
	 switch(guan)
	 {
	 	 case 1: return Current_Loc1[i][2];
		 break;

		 case 2: return Current_Loc2[i][2];
		 break;

		 case 3: return Current_Loc3[i][2];
		 break;

		 case 4: return Current_Loc4[i][2];
		 break;

		 case 5: return Current_Loc5[i][2];
		 break;	 
	 }

	 return 0; 
}



void currenttank_init(uchar key)
{      
 if(key%5 == 1)
 {
  phead1.Camp=Player;
  phead1.status=turn;
  phead1.Exist=1;
  phead1.Life=1;
  phead1.Level=1;
  phead1.Position[0]=5;
  phead1.Position[1]=15;
  phead1.Direction=Up;
  phead1.Tank_Bounce_Wall_Flg=0;
 // phead1.Tank_Bounce_Tank_Flg=0;
  phead1.Shot_Bounce_Home_Flg=0;

  phead1.Shot_Position[0]=5;
  phead1.Shot_Position[1]=15;
  phead1.Shot_Direction=Up;
  phead1.Send_Shot_Flg=0;
  phead1.Shot_Bounce_Wall_Flg=0;
  phead1.Shot_Bounce_Tank_Flg=0;
  //phead1.Shot_Bounce_Shot_Flg=0;
  phead1.Button_Down_Flg=0;

  phead1.next=&phead2;

  phead1.next->Camp=Enemy;
  phead1.next->status=turn;

  phead1.next->Exist=1;
  phead1.next->Life=5;
  phead1.next->Level=1;
  phead1.next->Position[0]=2;
  phead1.next->Position[1]=2;
  phead1.next->Direction=Down;
  phead1.next->Tank_Bounce_Wall_Flg=0;
 // phead1.next->Tank_Bounce_Tank_Flg=0;
  phead1.next->Shot_Bounce_Home_Flg=0;

  phead1.next->Shot_Position[0]=2;
  phead1.next->Shot_Position[1]=2;
  phead1.next->Shot_Direction=Down;
  phead1.next->Send_Shot_Flg=0;
  phead1.next->Shot_Bounce_Wall_Flg=0;
  phead1.next->Shot_Bounce_Tank_Flg=0;
  //phead1.next->Shot_Bounce_Shot_Flg=0;
  phead1.next->Button_Down_Flg=0;

  phead1.next->next=NULL;

   }
if(key%5==2)
 {
  phead1.Camp=Player;
  phead1.status=turn;
  phead1.Exist=1;
  phead1.Life=1;
  phead1.Level=1;
  phead1.Position[0]=5;
  phead1.Position[1]=15;
  phead1.Direction=Up;
  phead1.Tank_Bounce_Wall_Flg=0;
 // phead1.Tank_Bounce_Tank_Flg=0;
  phead1.Shot_Bounce_Home_Flg=0;

  phead1.Shot_Position[0]=5;
  phead1.Shot_Position[1]=15;
  phead1.Shot_Direction=Up;
  phead1.Send_Shot_Flg=0;
  phead1.Shot_Bounce_Wall_Flg=0;
  phead1.Shot_Bounce_Tank_Flg=0;
  //phead1.Shot_Bounce_Shot_Flg=0;
  phead1.Button_Down_Flg=0;

  phead1.next=&phead2;
 
  phead1.next->Camp=Enemy;
  phead1.next->status=turn;

  phead1.next->Exist=1;
  phead1.next->Life=1;
  phead1.next->Level=1;
  phead1.next->Position[0]=2;
  phead1.next->Position[1]=2;
  phead1.next->Direction=Down;
  phead1.next->Tank_Bounce_Wall_Flg=0;
 // phead1.next->Tank_Bounce_Tank_Flg=0;
  phead1.next->Shot_Bounce_Home_Flg=0;

  phead1.next->Shot_Position[0]=2;
  phead1.next->Shot_Position[1]=2;
  phead1.next->Shot_Direction=Down;
  phead1.next->Send_Shot_Flg=0;
  phead1.next->Shot_Bounce_Wall_Flg=0;
  phead1.next->Shot_Bounce_Tank_Flg=0;
  //phead1.next->Shot_Bounce_Shot_Flg=0;
  phead1.next->Button_Down_Flg=0;

  phead1.next->next=NULL;

  }
 if(key%5==3)
 {
  phead1.Camp=Player;
  phead1.status=turn;
  phead1.Exist=1;
  phead1.Life=1;
  phead1.Level=1;
  phead1.Position[0]=5;
  phead1.Position[1]=15;
  phead1.Direction=Up;
  phead1.Tank_Bounce_Wall_Flg=0;
 // phead1.Tank_Bounce_Tank_Flg=0;
  phead1.Shot_Bounce_Home_Flg=0;

  phead1.Shot_Position[0]=5;
  phead1.Shot_Position[1]=15;
  phead1.Shot_Direction=Up;
  phead1.Send_Shot_Flg=0;
  phead1.Shot_Bounce_Wall_Flg=0;
  phead1.Shot_Bounce_Tank_Flg=0;
 // phead1.Shot_Bounce_Shot_Flg=0;
  phead1.Button_Down_Flg=0;

  phead1.next=&phead2;

  phead1.next->Camp=Enemy;
  phead1.next->status=turn;

  phead1.next->Exist=1;
  phead1.next->Life=1;
  phead1.next->Level=1;
  phead1.next->Position[0]=2;
  phead1.next->Position[1]=2;
  phead1.next->Direction=Down;
  phead1.next->Tank_Bounce_Wall_Flg=0;
 // phead1.next->Tank_Bounce_Tank_Flg=0;
  phead1.next->Shot_Bounce_Home_Flg=0;

  phead1.next->Shot_Position[0]=2;
  phead1.next->Shot_Position[1]=2;
  phead1.next->Shot_Direction=Down;
  phead1.next->Send_Shot_Flg=0;
  phead1.next->Shot_Bounce_Wall_Flg=0;
  phead1.next->Shot_Bounce_Tank_Flg=0;
  //phead1.next->Shot_Bounce_Shot_Flg=0;
  phead1.next->Button_Down_Flg=0;

  phead1.next->next=NULL;

  }
 if(key%5==4)
 {
  phead1.Camp=Player;
  phead1.status=turn;
  phead1.Exist=1;
  phead1.Life=1;
  phead1.Level=1;
  phead1.Position[0]=5;
  phead1.Position[1]=15;
  phead1.Direction=Up;
  phead1.Tank_Bounce_Wall_Flg=0;
//  phead1.Tank_Bounce_Tank_Flg=0;
  phead1.Shot_Bounce_Home_Flg=0;

  phead1.Shot_Position[0]=5;
  phead1.Shot_Position[1]=15;
  phead1.Shot_Direction=Up;
  phead1.Send_Shot_Flg=0;
  phead1.Shot_Bounce_Wall_Flg=0;
  phead1.Shot_Bounce_Tank_Flg=0;
//  phead1.Shot_Bounce_Shot_Flg=0;
  phead1.Button_Down_Flg=0;

  phead1.next=&phead2;
 
  phead1.next->Camp=Enemy;
  phead1.next->status=turn;

  phead1.next->Exist=1;
  phead1.next->Life=1;
  phead1.next->Level=1;
  phead1.next->Position[0]=1;
  phead1.next->Position[1]=2;
  phead1.next->Direction=Down;
  phead1.next->Tank_Bounce_Wall_Flg=0;
//  phead1.next->Tank_Bounce_Tank_Flg=0;
  phead1.next->Shot_Bounce_Home_Flg=0;

  phead1.next->Shot_Position[0]=2;
  phead1.next->Shot_Position[1]=2;
  phead1.next->Shot_Direction=Down;
  phead1.next->Send_Shot_Flg=0;
  phead1.next->Shot_Bounce_Wall_Flg=0;
  phead1.next->Shot_Bounce_Tank_Flg=0;
 // phead1.next->Shot_Bounce_Shot_Flg=0;
  phead1.next->Button_Down_Flg=0;

  phead1.next->next=NULL;

 }
 if(key%5 ==0 || key==5)
 {
  phead1.Camp=Player;
  phead1.status=turn;
  phead1.Exist=1;
  phead1.Life=1;
  phead1.Level=1;
  phead1.Position[0]=5;
  phead1.Position[1]=15;
  phead1.Direction=Up;
  phead1.Tank_Bounce_Wall_Flg=0;
 // phead1.Tank_Bounce_Tank_Flg=0;
  phead1.Shot_Bounce_Home_Flg=0;

  phead1.Shot_Position[0]=5;
  phead1.Shot_Position[1]=15;
  phead1.Shot_Direction=Up;
  phead1.Send_Shot_Flg=0;
  phead1.Shot_Bounce_Wall_Flg=0;
  phead1.Shot_Bounce_Tank_Flg=0;
 // phead1.Shot_Bounce_Shot_Flg=0;
  phead1.Button_Down_Flg=0;

  phead1.next=&phead2;

  phead1.next->Camp=Enemy;
  phead1.next->status=turn;
  phead1.next->Exist=1;
  phead1.next->Life=1;
  phead1.next->Level=1;
  phead1.next->Position[0]=2;
  phead1.next->Position[1]=13;
  phead1.next->Direction=Down;
  phead1.next->Tank_Bounce_Wall_Flg=0;
 // phead1.next->Tank_Bounce_Tank_Flg=0;
  phead1.next->Shot_Bounce_Home_Flg=0;
  phead1.next->Shot_Position[0]=2;
  phead1.next->Shot_Position[1]=2;
  phead1.next->Shot_Direction=Down;
  phead1.next->Send_Shot_Flg=0;
  phead1.next->Shot_Bounce_Wall_Flg=0;
  phead1.next->Shot_Bounce_Tank_Flg=0;
  //phead1.next->Shot_Bounce_Shot_Flg=0;
  phead1.next->Button_Down_Flg=0;

  phead1.next->next=NULL;

  phead1.next->next=&phead3;

  phead3.Camp=Enemy;
  phead3.status=turn;
  phead3.Exist=1;
  phead3.Life=1;
  phead3.Level=1;
  phead3.Position[0]=4;
  phead3.Position[1]=2;
  phead3.Direction=Down;
  phead3.Tank_Bounce_Wall_Flg=0;
 // phead3.Tank_Bounce_Tank_Flg=0;
  phead3.Shot_Bounce_Home_Flg=0;
  phead3.Shot_Position[0]=1;
  phead3.Shot_Position[1]=13;
  phead3.Shot_Direction=Down;
  phead3.Send_Shot_Flg=0;
  phead3.Shot_Bounce_Wall_Flg=0;
  phead3.Shot_Bounce_Tank_Flg=0;
 // phead3.Shot_Bounce_Shot_Flg=0;
  phead3.Button_Down_Flg=0;
 
  phead3.next=NULL;
 }

  para.Top= &phead1;
}
#if a

void  currentmap_Loc_init(uchar key)
{
	 
	if(key%5==1)
	{
		para.Current_barrier_num=map_barrier_num[0];

		para.init_tank_num=2;
		para.Current_tank_num=2;
		para.guan_qia=1;
		para.all_score=0;
		para.time_account=59;
		para.destroye_num=0;
	}
	if(key%5==2)
	{
	
		para.Current_barrier_num=map_barrier_num[1];

		para.init_tank_num=2;
		para.Current_tank_num=2;
		para.guan_qia=2;
		para.all_score=0;
		para.time_account=59;
		para.destroye_num=0;
	}
	if(key%5==3)
	{
		para.Current_barrier_num=map_barrier_num[2];

		para.init_tank_num=2;
		para.Current_tank_num=2;
		para.guan_qia=3;
		para.all_score=0;
		para.time_account=59;
		para.destroye_num=0;
	}
	if(key%5==4)
	{
		para.Current_barrier_num=map_barrier_num[3];

		para.init_tank_num=2;
		para.Current_tank_num=2;
		para.guan_qia=4;
		para.all_score=0;
		para.time_account=59;
		para.destroye_num=0;
	}
	if(key%5==0 || key==0)
	{
    	para.Current_barrier_num=map_barrier_num[4];

		para.init_tank_num=3;
		para.Current_tank_num=3;
		para.guan_qia=5;
		para.all_score=0;
		para.time_account=59;
		para.destroye_num=0;
	}
}

uchar choose_enemy_Tank_move_turn_shot()
{
  uchar i,flag;
  srand(counter);
  i=rand()%10+1;
  if(i>=7 && i<=9)
 {
  flag=1;//turn
 }
 if(i>=4 && i<=6)
 {
  flag=2;//move
 }
 if(i==10)
 {
  flag=3;//shot
 }
 if(i>=1 && i<=3)   
 {
  flag=4;//stop
 }
 
 return flag;
}
/*
uchar RandCtrl_enemy_Tank_movecount()
{
	 uchar i;
//	srand(time(0));
	 i=rand()%10+1;
	
	return i;
}*/
uchar RandCtrl_enemy_Tank_Direction()
{
	uchar i;
	srand(counter);
	 i=rand()%256;
		
	if(i<=50)
	{
		i=Up;
	}
	if(i>50&&i<=100)
	{
		i=Down;
	}
	if(i>100&&i<=150)
	{
		i=Left;
	}
	if(i>150)
	{
		i=Right;
	}
	return i;
}
#endif

#if b
/*
void Tank_Tank_Check(struct TANK *t)
{
	uchar  tank_Check_num=para.init_tank_num;
	tank  temp_tank=NULL;

	temp_tank=para.Top;

	switch(t->Direction)
	{
		case Up:
					while(tank_Check_num--)
					{	if(temp_tank->Exist==1 && (t->Position[1]-1)==temp_tank->Position[1] && t->Position[0]==temp_tank->Position[0])
						{
							t->Tank_Bounce_Tank_Flg=1;
							//temp_tank->Tank_Bounce_Tank_Flg=1;
							break;
						}
						temp_tank=temp_tank->next;
					}
			
					break;

		case Down:
				while(tank_Check_num--)
					{
						if(temp_tank->Exist==1 && (t->Position[1]+1)==temp_tank->Position[1] && t->Position[0]==temp_tank->Position[0])
						{
							t->Tank_Bounce_Tank_Flg=1;
							//temp_tank->Tank_Bounce_Tank_Flg=1;
							break;
						}
						temp_tank=temp_tank->next;
					}
				break;

		case Left:
				while(tank_Check_num--)
					{
						if(temp_tank->Exist==1 && t->Position[1]==temp_tank->Position[1] && (t->Position[0]-1)==temp_tank->Position[0])
						{
							t->Tank_Bounce_Tank_Flg=1;
							//temp_tank->Tank_Bounce_Tank_Flg=1;
							break;
						}
						temp_tank=temp_tank->next;
					}
				break;

		case Right:
				while(tank_Check_num--)
					{
						if(temp_tank->Exist==1 && t->Position[1]+1==temp_tank->Position[1] && (t->Position[0]+1)==temp_tank->Position[0])
						{
							t->Tank_Bounce_Tank_Flg=1;
							//temp_tank->Tank_Bounce_Tank_Flg=1;
							break;
						}
						temp_tank=temp_tank->next;
					}
				break;
	}
	
}
*/
//���㴦������ 
uchar Cheak_wall(uchar i)
{	
	switch(i%8)
	{
	case 0: if(Current_Loc_Sit[i/8] &= 0x01) return 0 ;  else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x01; return 1 ;} break;
	case 1: if(Current_Loc_Sit[i/8] &= 0x02) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x02; return 1 ;} break;
	case 2: if(Current_Loc_Sit[i/8] &= 0x04) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x04; return 1 ;} break;
	case 3: if(Current_Loc_Sit[i/8] &= 0x08) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x08; return 1 ;} break;
	case 4: if(Current_Loc_Sit[i/8] &= 0x10) return 0 ;  else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x10; return 1 ;} break;
	case 5: if(Current_Loc_Sit[i/8] &= 0x20) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x20; return 1 ;} break;
	case 6: if(Current_Loc_Sit[i/8] &= 0x40) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x40; return 1 ;} break;
	case 7: if(Current_Loc_Sit[i/8] &= 0x80) return 0 ;	 else{ if(Cheak_wall_flg)Current_Loc_Sit[i/8] |= 0x80; return 1 ;} break;	
	}

	return 0;
}

																	
void Tank_Wall_Check(struct TANK *t)
{
	 barrier p=NULL;
	 uchar 	Barrier_num;
	 int i;
	 Cheak_wall_flg = 0;
	 Barrier_num=para.Current_barrier_num;
		switch(t->Direction)
		{
			case Up:
					if(t->Position[1]==0)
					 {
					    t->Tank_Bounce_Wall_Flg=1;						
					 }
					 else
					 {
					 	for(i=0;i<Barrier_num;i++)
						{
							 if( find_x(para.guan_qia, i) == t->Position[0] && find_y(para.guan_qia, i) == (t->Position[1] -1) )
						     {														
							    	if(find_q(para.guan_qia, i) == 3)
									{	Cheak_wall_flg = 1;															    	
										if(Cheak_wall(i))
									    {
										  Tank_zidan_3 =1 ;   
								    	}
									 }
									 else
									 {
									 
									    if(Cheak_wall(i))
									    {
									      t->Tank_Bounce_Wall_Flg=1;
								    	}								 
									 }
									break;
																																			
							 }						 							
						}					
					 }
					 break;
	
			case Down:
						if(t->Position[1]==15)
						 {
						    t->Tank_Bounce_Wall_Flg=1;
							
						 }
						  else
						 {
						 	for(i=0;i<Barrier_num;i++)
							{
							if(find_x(para.guan_qia, i)==t->Position[0] && find_y(para.guan_qia, i) == (t->Position[1] + 1))
						     {								
							     if(find_q(para.guan_qia, i) == 3)
									{	Cheak_wall_flg = 1	;														    	
										if(Cheak_wall(i))
									    {
										  Tank_zidan_3 =1 ;								      
								    	}

									 }
									 else
									 {
									 
									    if(Cheak_wall(i))
									    {
									      t->Tank_Bounce_Wall_Flg=1;
								    	}								 
									 }
									break;																									
							 }
							}
							
						 }
						 break;
	
			case Left:
						if(t->Position[0]==0)
						 {
						    t->Tank_Bounce_Wall_Flg=1;
														
						 }
						  else
						 {
						 	for(i=0;i<Barrier_num;i++)
							{
								if(find_x(para.guan_qia, i)==(t->Position[0]-1) && find_y(para.guan_qia, i) == t->Position[1] )
						     {								
							
							    if(find_q(para.guan_qia, i) == 3)
									{	Cheak_wall_flg = 1;															    	
										if(Cheak_wall(i))
									    {
										  Tank_zidan_3 =1 ;
									      
								    	}

									 }
									 else
									 {
									 
									    if(Cheak_wall(i))
									    {
									      t->Tank_Bounce_Wall_Flg=1;
								    	}								 
									 }
									break;
																																				
							 }
							}
							
						 }
						 break;

			case Right:
						if(t->Position[0]==14)
						 {
						    t->Tank_Bounce_Wall_Flg=1;
							
						 }
						  else
						 {
						 	for(i=0;i<Barrier_num;i++)
							{
							if(find_x(para.guan_qia, i)==(t->Position[0]+1) && find_y(para.guan_qia, i) == t->Position[1] )
						     {								
							
							    if(find_q(para.guan_qia, i) == 3)
									{	Cheak_wall_flg = 1;															    	
										if(Cheak_wall(i))
									    {
										  Tank_zidan_3 =1 ;  
								    	}

									 }
									 else
									 {			 
									    if(Cheak_wall(i))
									    {
									      t->Tank_Bounce_Wall_Flg=1;
								    	}								 
									 }
									break;																																			
							 }
							}							
						 }
						 break;
		}
}

void  Shot_Wall_Check(struct TANK *t)
{
	 uchar 	Barrier_num;
	 int i;
	 Barrier_num=para.Current_barrier_num;
	 Cheak_wall_flg = 1;

	if(t->Send_Shot_Flg)
	{
	switch(t->Shot_Direction)
	{
		case Up:
				if(t->Shot_Position[1]==0)
				{			
				    
					set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			        write_one(0x00, INC_WR);
					t->Send_Shot_Flg = 0 ;				
				}				 
				 else
				 {
				 	for(i=0;i<Barrier_num;i++)
					{
						if( (find_x(para.guan_qia, i)==t->Shot_Position[0]) && find_y(para.guan_qia, i)==(t->Shot_Position[1] - 1))
							{

							   if(find_q(para.guan_qia, i) == 2)
							   {
							   if(Cheak_wall(i))
							   {
							    set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
							    set_xy(t->Shot_Position[0],t->Shot_Position[1]-1);
			                    write_one(0x9d, INC_WR);
								set_xy(t->Shot_Position[0], t->Shot_Position[1]-1);
			                    write_one(0xa4, INC_WR);
								t->Send_Shot_Flg = 0 ;							
								}
								}
								else
								{
									Cheak_wall_flg = 0;								
							     	if(Cheak_wall(i))
							        {
							     	set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                        write_one(0xa4, INC_WR);
							    	t->Send_Shot_Flg = 0 ;							
							    	}
						    	}
								break;
																																				
							}
							
					}
					
				 }
				 break;

		case Down:
					if(t->Shot_Position[1]==15)
					 {
					   
						set_xy(t->Shot_Position[0],t->Shot_Position[1]);
				        write_one(0xa4, INC_WR);
						t->Send_Shot_Flg = 0 ;
					
					 }
					  else
					 {
					 	if( (find_x(para.guan_qia, i)==t->Shot_Position[0]) && find_y(para.guan_qia, i)==(t->Shot_Position[1] + 1))
							{
							    if(find_q(para.guan_qia, i) == 2)
							   {
							   if(Cheak_wall(i))
							   {
							   set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
							    set_xy(t->Shot_Position[0], t->Shot_Position[1]+1);
			                    write_one(0x9d, INC_WR);
								set_xy(t->Shot_Position[0], t->Shot_Position[1]+1);
			                    write_one(0xa4, INC_WR);	
								t->Send_Shot_Flg = 0 ;														
								}
								}
								else
								{
									Cheak_wall_flg = 0;								
							     	if(Cheak_wall(i))
							        {
							     	set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                        write_one(0xa4, INC_WR);
							    	t->Send_Shot_Flg = 0 ;							
							    	}
						    	}
								break;																												
							}
						
					 }
					 break;
		case Left:
					if(t->Shot_Position[0]==0)
					 {
					   
						 set_xy(t->Shot_Position[0], t->Shot_Position[1]);
				        write_one(0xa4, INC_WR);
						t->Send_Shot_Flg = 0 ;
							
					 }
					  else
					 {
					 	if( (find_x(para.guan_qia, i)==t->Shot_Position[0]-1) && find_y(para.guan_qia, i)==(t->Shot_Position[1] - 1))
							{
							   if(find_q(para.guan_qia, i) == 2)
							   {
							   if(Cheak_wall(i))
							   {
							    set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
							    set_xy(t->Shot_Position[0]-1, t->Shot_Position[1]);
			                    write_one(0x9d, INC_WR);
								set_xy(t->Shot_Position[0]-1, t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
								t->Send_Shot_Flg = 0 ;							
								}
								}
								else
								{
									Cheak_wall_flg = 0;								
							     	if(Cheak_wall(i))
							        {
							     	set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                        write_one(0xa4, INC_WR);
							    	t->Send_Shot_Flg = 0 ;							
							    	}
						    	}
								break;																												
							}
						
					 }
					 break;
		case Right:
					if(t->Shot_Position[0]==14)
					 {
					    t->Shot_Bounce_Wall_Flg=1;
						set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			            write_one(0xa4, INC_WR);
					    t->Send_Shot_Flg = 0 ;			
					 }
					  else
					 {
					 	if( (find_x(para.guan_qia, i)==t->Shot_Position[0]+1) && find_y(para.guan_qia, i)==(t->Shot_Position[1]))
							{
							 if(find_q(para.guan_qia, i) == 2)
							   {
							   if(Cheak_wall(i))
							   {
								set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
							    set_xy(t->Shot_Position[0]+1, t->Shot_Position[1]);
			                    write_one(0x9d, INC_WR);
								set_xy(t->Shot_Position[0]+1,t->Shot_Position[1]);
			                    write_one(0xa4, INC_WR);
								t->Send_Shot_Flg = 0 ;							
								}
								}
								else
								{
									Cheak_wall_flg = 0;								
							     	if(Cheak_wall(i))
							        {
							     	set_xy(t->Shot_Position[0], t->Shot_Position[1]);
			                        write_one(0xa4, INC_WR);
							    	t->Send_Shot_Flg = 0 ;							
							    	}
						    	}
								break;																												
							}
						
					 }
					 break;

		}
		
	   }
}

void Shot_Tank_Check(struct TANK *t)
{

	uchar  tank_Check_num=para.init_tank_num;
	tank  temp_tank=NULL;

	temp_tank=para.Top;

	if(t->Send_Shot_Flg)
	{
	switch(t->Direction)
	{
		case Up:
					while(tank_Check_num--)
					{
						if(temp_tank->Exist && t->Shot_Position[1]-1==temp_tank->Position[1] && t->Shot_Position[0]==temp_tank->Position[0])
						{
							t->Shot_Bounce_Tank_Flg=2;
							temp_tank->Shot_Bounce_Tank_Flg=1;							
							break;
						}
						temp_tank=temp_tank->next;
					}			
					break;

		case Down:
					while(tank_Check_num--)
						{
							if(temp_tank->Exist && t->Shot_Position[1]+1==temp_tank->Position[1] && t->Shot_Position[0]==temp_tank->Position[0])
							{
								t->Shot_Bounce_Tank_Flg=2;						
								temp_tank->Shot_Bounce_Tank_Flg=1;
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;

		case Left:
					while(tank_Check_num--)
						{
							if(temp_tank->Exist && t->Shot_Position[1]==temp_tank->Position[1] && t->Shot_Position[0]-1==temp_tank->Position[0])
							{
								t->Shot_Bounce_Tank_Flg=2;							
								temp_tank->Shot_Bounce_Tank_Flg=1;
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;

		case Right:
					while(tank_Check_num--)
						{
							if(temp_tank->Exist && t->Shot_Position[1]==temp_tank->Position[1] && t->Shot_Position[0]+1==temp_tank->Position[0])
							{
								t->Shot_Bounce_Tank_Flg=2;
								temp_tank->Shot_Bounce_Tank_Flg=1;
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;
	}

	}

}
/*
void Shot_Shot_Check(struct TANK *t)
{
	uchar  tank_Check_num=para.init_tank_num;
	tank  temp_tank=NULL;

	temp_tank=para.Top;

	if(t->Send_Shot_Flg)
	{
	switch(t->Direction)
	{
		case Up:
					while(tank_Check_num--)
					{
						if(temp_tank->Send_Shot_Flg && temp_tank->Exist==1 && (t->Shot_Position[1]-1)==temp_tank->Shot_Position[1] && t->Shot_Position[0]==temp_tank->Shot_Position[0])
						{
							t->Shot_Bounce_Shot_Flg=1;							
							temp_tank->Shot_Bounce_Shot_Flg=1;
							break;
						}
						temp_tank=temp_tank->next;
					}			
					break;

		case Down:
					while(tank_Check_num--)
						{
							if(temp_tank->Send_Shot_Flg && temp_tank->Exist==1 && (t->Shot_Position[1]+1)==temp_tank->Shot_Position[1] && t->Shot_Position[0]==temp_tank->Shot_Position[0])
							{
								t->Shot_Bounce_Shot_Flg=1;								
								temp_tank->Shot_Bounce_Shot_Flg=1;
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;

		case Left:
					while(tank_Check_num--)
						{
							if(temp_tank->Send_Shot_Flg && temp_tank->Exist==1 && t->Shot_Position[1]==temp_tank->Shot_Position[1] && t->Shot_Position[0]-1==temp_tank->Shot_Position[0])
							{
								t->Shot_Bounce_Shot_Flg=1;
								temp_tank->Shot_Bounce_Shot_Flg=1;
								
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;

		case Right:
					while(tank_Check_num--)
						{
							if(temp_tank->Send_Shot_Flg && temp_tank->Exist==1 && t->Shot_Position[1]+1==temp_tank->Shot_Position[1] && t->Shot_Position[0]+1==temp_tank->Shot_Position[0])
							{
								t->Shot_Bounce_Shot_Flg=1;
								temp_tank->Shot_Bounce_Shot_Flg=1;
								break;
							}
							temp_tank=temp_tank->next;
						}
					break;

	}

	}
}
 */
void Shot_Home_Check(struct TANK *t)
{
	if(t->Send_Shot_Flg)
	{
	switch(t->Direction)
	{
		case Down:
					
					if(t->Shot_Position[0] == 7 && t->Shot_Position[1]+1==15)
					{
						t->Shot_Bounce_Home_Flg=1;
					}
					break;

		case Left:
					if( t->Shot_Position[0]-1 == 7 && t->Shot_Position[1] == 15 )
					{
						t->Shot_Bounce_Home_Flg=1;


					}
					break;

		case Right:
					if(t->Shot_Position[0]+1 == 7 && t->Shot_Position[1]==15)
					{
						t->Shot_Bounce_Home_Flg=1;


					}
					break;

	}

	}
}

void player_tank_move(struct TANK *player)
{	   
	if(player->Button_Down_Flg)
	{
		switch(player->Direction)
		{
			case Up:
					 set_xy(player->Position[0],player->Position[1]);		   //���Լ�λ��
					 write_one(0xa4,INC_WR);
					 set_xy(player->Position[0],player->Position[1]-1);
					 write_one(0xa6,INC_WR);
					 player->Position[1]-=1;
					 break;
	
			case Down:
					 set_xy(player->Position[0],player->Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(player->Position[0],player->Position[1]+1);
					 write_one(0xa1,INC_WR);
					 player->Position[1]+=1;
					 break;
	
			case Left:
					 set_xy(player->Position[0],player->Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(player->Position[0]-1,player->Position[1]);
					 write_one(0xa2,INC_WR);
					 player->Position[0]-=1;
					 break;
			case Right:
					 set_xy(player->Position[0],player->Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(player->Position[0]+1,player->Position[1]);
					 write_one(0xa3,INC_WR);
					 player->Position[0]+=1;
					 break;
	
		} 
		player->Button_Down_Flg = 0;
	}
}

void Shot_move(struct TANK *t)
{	   

		switch(t->Shot_Direction)
		{
			case Up:			         
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]-1);
					 write_one(0x9d,INC_WR);
					 t->Shot_Position[1]-=1;
					 break;
	
			case Down:
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]+1);
					 write_one(0x9d,INC_WR);
					 t->Shot_Position[1]+=1;
					 break;
	
			case Left:
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(t->Shot_Position[0]-1,t->Shot_Position[1]);
					 write_one(0x9d,INC_WR);
					 t->Shot_Position[0]-=1;
					 break;
			case Right:
					 set_xy(t->Shot_Position[0],t->Shot_Position[1]);
					 write_one(0xa4,INC_WR);
					 set_xy(t->Shot_Position[0]+1,t->Shot_Position[1]);
					 write_one(0x9d,INC_WR);
					 t->Shot_Position[0]+=1;
					 break;
	
		} 

}
	
void enemy_tank_move(struct TANK *enemy)
{

  switch(enemy->Direction)
  {
   case Up:
     
      set_xy(enemy->Position[0],enemy->Position[1]);
      write_one(0xa4,INC_WR);
      set_xy(enemy->Position[0],enemy->Position[1]-1);
      write_one(0xa6,INC_WR);
      enemy->Position[1]=enemy->Position[1]-1;

      break;
 
   case Down:
   
      set_xy(enemy->Position[0],enemy->Position[1]);
      write_one(0xa4,INC_WR);
      set_xy(enemy->Position[0],enemy->Position[1]+1);
      write_one(0xa1,INC_WR);

      enemy->Position[1]=enemy->Position[1]+1;
      break;
 
   case Left:
      set_xy(enemy->Position[0],enemy->Position[1]);
      write_one(0xa4,INC_WR);
      set_xy(enemy->Position[0]-1,enemy->Position[1]);
      write_one(0xa2,INC_WR);
      enemy->Position[0]=enemy->Position[0]-1;
      break;
   case Right:
      set_xy(enemy->Position[0],enemy->Position[1]);
      write_one(0xa4,INC_WR);
      set_xy(enemy->Position[0]+1,enemy->Position[1]);
      write_one(0xa3,INC_WR);
      enemy->Position[0]=enemy->Position[0]+1;
      break;
 
  } 
    
}

void flag_bounce_deal(struct TANK *t)
{
	uchar 	Barrier_num;

	Barrier_num = para.Current_barrier_num;
 
	if (t->Camp == Enemy && t->status==turn && !t->Tank_Bounce_Wall_Flg)				   //�д���
	{	
		switch (RandCtrl_enemy_Tank_Direction())
		{
		case Up:
		
			set_xy(t->Position[0], t->Position[1]);
			write_one(0xa1, INC_WR);		
			t->Direction = Up  ;			
			break;
		
		case Down:
		
			set_xy(t->Position[0], t->Position[1]);
			write_one(0xa6, INC_WR);		
			t->Direction = Down;
			break;
		
		case Left:
		
			set_xy(t->Position[0], t->Position[1]);
			write_one(0xa3, INC_WR);		
			t->Direction = Left;			
			break;
		
		case Right:
		
			set_xy(t->Position[0], t->Position[1]);
			write_one(0xa2, INC_WR);		
			t->Direction = Right;
			break;
		}
	}	  

	if ((t->status==move) && !(t->Shot_Bounce_Wall_Flg || t->Shot_Bounce_Tank_Flg || t->Tank_Bounce_Wall_Flg))
	{
		 if (t->Camp==Player)
		 player_tank_move(t);

		 if (t->Camp==Enemy)
		 enemy_tank_move(t);	
	} 

   if (t->Send_Shot_Flg && !(t->Shot_Bounce_Wall_Flg || t->Shot_Bounce_Tank_Flg || t->Shot_Bounce_Home_Flg))
		Shot_move(t);
			
	
			
	if (t->Tank_Bounce_Wall_Flg)
	{
		switch (t->Direction)
		{
		case Up:
			set_xy(t->Position[0],t->Position[1]);
			write_one(0xa1 ,INC_WR);
			t->Direction = Down;
		//	t->Tank_Bounce_Tank_Flg = 0;
			t->Tank_Bounce_Wall_Flg = 0;
			break;

		case Down:

			set_xy(t->Position[0],t->Position[1]);
			write_one(0xa6 ,INC_WR);

			t->Direction = Up;
		//	t->Tank_Bounce_Tank_Flg = 0;
			t->Tank_Bounce_Wall_Flg = 0;
			break;

		case Left:

			set_xy(t->Position[0],t->Position[1]);
			write_one(0xa3 ,INC_WR);

			t->Direction = Right;
		//	t->Tank_Bounce_Tank_Flg = 0;
			t->Tank_Bounce_Wall_Flg = 0;
			break;

		case Right:

			set_xy(t->Position[0],t->Position[1]);
			write_one(0xa2 ,INC_WR);
			t->Direction = Left;
		//	t->Tank_Bounce_Tank_Flg = 0;
			t->Tank_Bounce_Wall_Flg = 0;

			break;
		}
		t->status = stop;
		t->Button_Down_Flg = 0 ; 
	}

	  
  	if (t->Shot_Bounce_Tank_Flg )
	{
	 if(t->Shot_Bounce_Tank_Flg == 1)	
	 {	
		   if(t->Camp==Enemy)
		   {
		   	if(Tank_zidan_3)
			para.destroye_num+=5;
			else
			para.destroye_num++;
		   }
	
			 if(Tank_zidan_3)
			 {
			 t->Life-=5;
			 Tank_zidan_3 = 0 ;
			 }
			 else
		     t->Life--;
	
			t->Shot_Bounce_Tank_Flg=0;
		   
			if (t->Life <= 0)
			{
				t->Exist = 0;
				para.Current_tank_num--;
	
				set_xy(t->Position[0], t->Position[1]);
				write_one(0xa4, INC_WR);
				set_xy(t->Shot_Position[0], t->Shot_Position[1]);
				write_one(0xa4, INC_WR);
			}
	   }
	   else
	   {
	   	  	set_xy(t->Shot_Position[0], t->Shot_Position[1]);
	    	write_one(0xa4, INC_WR);

	    	t->Shot_Bounce_Tank_Flg=0;
	    	t->Send_Shot_Flg=0;				    
	   }
	   
	     	   							
	}


	if (t->Shot_Bounce_Tank_Flg )
	{
	   set_xy(t->Shot_Position[0], t->Shot_Position[1] );
	   write_one(0xa4, INC_WR);

	   set_xy(7,15 );
	   write_one(0xa0, INC_WR);		
	}
}
#endif
 uchar flg = 1;
#if c
void get_tank_statuanddeal()
{
	uchar i;
	tank t;
	t=para.Top;
	key_score = para.destroye_num ;

	if(!((para.Top)->Exist) || (para.Top)->Shot_Bounce_Home_Flg || ((para.Current_tank_num<=1)&&(para.Top)->Exist) || para.time_account==60)	
	 {		


			for(i=0; i<9; i++)
			{
			   Current_Loc_Sit[i]=0;
			}
			
	        time_flg = 0;	  		
			if(flg)
			{
			cls();
			score_account_lcd();
			flg = 0 ;				
			}
			game_after_lcd(); 

			key_status=0;
			while(!key_status);

			if(key_status)
			{	
				flg = 1;
				switch(key_status)
				{
				case 1:	
						cls();
						lcd_start();
						flag=0;
						key_status=0;			
						break;
						
				case 2:	
						cls();
						time_flg = 1;//��Ҫ�޸ĵĵط�
					
						currentmap_Loc_init(++para.guan_qia);	//bug
						currenttank_init(para.guan_qia);
						key_status=0;
						 
						switch(para.guan_qia)
						{
							case 1:	map1();			
									break;
							case 2:	map2();			
									break;
							case 3:	map3();			
									break;
							case 4:	map4();			
									break;
							case 5:	map5();			
									break;
						}				
							
						break;

				case 3:	
						key_status=0;
						cls();
						chooze_game_lcd();
						delay_1s();	
		                delay_1s();
						while (!key_status);
						switch (key_status)
						{
						case 1:
						key_status = 0 ;
							cls();
					    	time_flg = 1 ;
					    	currentmap_Loc_init(1);
						    currenttank_init(1);		
							key_status = 0;
							map1();			
			
							break;
			
						case 2:
						key_status = 0 ;
							cls();
					    	time_flg = 1 ;
					    	currentmap_Loc_init(2);
						    currenttank_init(2);
							map2();
			
							break;
			
						case 3:
						key_status = 0 ;
							cls();
					    	time_flg = 1 ;
					    	currentmap_Loc_init(3);
						    currenttank_init(3);
							key_status = 0;
								map3();
			
							break;
			
						case 4:
						key_status = 0 ;
							cls();
					    	time_flg = 1 ;
					    	currentmap_Loc_init(4);
						    currenttank_init(4);
								map4();
			
							break;
			
						case 5:
						key_status = 0 ;
							cls();
					    	time_flg = 1 ;
					    	currentmap_Loc_init(5);
						    currenttank_init(5);
							map5();
			
							break;			
						}
								
						break;			
				}
		    }
		}	
		else
		{
			while(t)
			{
				if(t->Exist && (t->Camp==Enemy))
				{
					t->status= choose_enemy_Tank_move_turn_shot();//change ,move, shot					
					if(t->status == shot && !t->Send_Shot_Flg)
					{

					switch(	t->Direction)
					{
					case 1:			
				   	t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0];
				    t->Shot_Position[1] = t->Position[1] - 1;
					break;
									
		        	case 2:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0];
				    t->Shot_Position[1] = t->Position[1] + 1;
					break;
									
			        case 3:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0] - 1;
				    t->Shot_Position[1] = t->Position[1];
					break;				
					
		        	case 4:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0] + 1;
				    t->Shot_Position[1] = t->Position[1];
					break;													
					}
					}
					check_tank_behavior(t);												
				}
				else
				{
					 if(t->Exist && (t->Camp==Player))
					 {
					 	 Button_Down_Checkanddeal(t ,key_status);	
					 }
				}
			
				t=t->next;		
			}


			t=para.Top;

			while(t)
			{
				flag_bounce_deal(t);
				t=t->next;
			}
							
		} 
}

void Start_Game()
{	
    uchar i ;
	lcd_start();
	switch (key_status)
	{		
		case 1:
		{
			cls();
			introduce_game_lcd();
			delay_1s();	
			key_status = 0 ;
			while (key_status != 1 ); 
			key_status = 0 ;
			delay_1s();
			cls(); 
		}
		break;
		case 2:
		{
			cls();
			chooze_game_lcd();
			delay_1s();	
			delay_1s();
		    flag=1;
			key_status = 0 ;	
			while(key_status == 0);
			switch (key_status)
			{		
					case 1:
					{	key_status = 0 ;
						cls();	 
						time_flg = 1 ;
						time_init();
						map1();
						currentmap_Loc_init(1);
						currenttank_init(1);
							
						while (flag)
						{
						  get_tank_statuanddeal();
						  delay(15000);
						}

					 }break;
		
					case 2:
						{key_status = 0 ;
						cls();	 
						time_flg = 1 ;
						time_init();
						currentmap_Loc_init(2);
						currenttank_init(2);
						map2();	
						while (flag)
						{
						  get_tank_statuanddeal();
						   delay(15000);
						}

					 }break;
		
					case 3:
						{key_status = 0 ;
						cls();	 
						time_flg = 1 ;
						time_init();
						currentmap_Loc_init(3);
						currenttank_init(3);
						map3();	
						while (flag)
						{
						  get_tank_statuanddeal();
						   delay(15000);
						}

					 }break;
		
					case 4:
						{ key_status = 0 ;
						cls();	 
						time_flg = 1 ;
						time_init();
						currentmap_Loc_init(4);
						currenttank_init(4);
						map4();	
						while (flag)
						{
						  get_tank_statuanddeal();
						   delay(15000);
						}

					 }break;
		
					case 5:
						{key_status = 0 ;
						cls();	 
						time_flg = 1 ;
						time_init();
						currentmap_Loc_init(5);
						currenttank_init(5);
						map5();	
						while (flag)
						{
						  get_tank_statuanddeal();
						   delay(15000);
						}

					 }break;
			}
		}
			break;
		case 3:
		{	key_status = 0 ;
			cls();
			ranking_list_lcd();
			i=10;
           while(i--)
           {
           delay_1s();
           }  
           cls();  
		 }
			break;

		}
	

}

void check_tank_behavior(struct TANK *t)
{	 
//	 Tank_Tank_Check(t);
	 Tank_Wall_Check(t);	 

	 Shot_Tank_Check(t);
	 Shot_Wall_Check(t);   
//	 Shot_Shot_Check(t);
	 Shot_Home_Check(t);
}


void Button_Down_Checkanddeal(struct TANK *t , char x )
{
	     	switch(x)
			{
			case 1:			
				   	t->Direction=Up;
					set_xy(t->Position[0], t->Position[1]);
					write_one(0xa6, INC_WR);
					t->Button_Down_Flg = 1 ;
					t->status=move;
					break;
									
			case 2:	
					t->Direction = Down;
					set_xy(t->Position[0], t->Position[1]);
					write_one(0xa1, INC_WR);
					t->Button_Down_Flg = 1 ;
					t->status=move;
					break;
					
			case 3:	
					t->Direction = Left;
					set_xy(t->Position[0], t->Position[1]);
					write_one(0xa2, INC_WR);
				   	t->Button_Down_Flg = 1 ;
					t->status=move;
					break;
					
			case 4:	
					t->Direction = Right;
					set_xy(t->Position[0], t->Position[1]);
					write_one(0xa3, INC_WR);
					t->Button_Down_Flg = 1 ;
					t->status=move;
					break;
					
			case 5:	
			if(!t->Send_Shot_Flg )
			{		
					switch(	t->Direction)
					{
					case 1:			
				   	t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0];
				    t->Shot_Position[1] = t->Position[1] - 1;
					break;
				
									
		        	case 2:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0];
				    t->Shot_Position[1] = t->Position[1] + 1;
					break;
				
					
			        case 3:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0] - 1;
				    t->Shot_Position[1] = t->Position[1];
					break;
				
					
		        	case 4:	
					t->Send_Shot_Flg = 1 ;																		 
				    t->Shot_Direction = t->Direction;
					t->Shot_Position[0] = t->Position[0] + 1;
				    t->Shot_Position[1] = t->Position[1];
					break;														
					}
			}
					break;

			case 6:			
					while(key_status);
					break;
			}

			check_tank_behavior(t);

			key_status=0;

}			


#endif













