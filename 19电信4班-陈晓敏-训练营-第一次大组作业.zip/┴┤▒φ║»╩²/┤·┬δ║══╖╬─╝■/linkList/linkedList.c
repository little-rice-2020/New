#include "../head/linkedList.h"
#include <stdio.h>
#include <stdlib.h>
#define LENS sizeof(struct LNode)

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L) {
	
	*L=(struct LNode *)malloc(LENS);
	(*L)->next=NULL;	
	
	if(!(*L))
	return ERROR;
	else
	return SUCCESS;

//	free(*L);	

}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L) {
	
	LinkedList p;
	if(*L==NULL)
	exit(EXIT_FAILURE);
	
	while(*L)
	{
		p=(*L)->next;
		free(*L);
		*L=p;
	}

}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q) {

}
/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e) {

}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L) {

	L=L->next;
	while(L!=NULL)
	{
		printf("%d\n",L->data);
		L=L->next;
	}
	printf("�����������\n"); 
	
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
	
	LNode *pn;
	int k, i;
	
	k=creat_list_length(L);
	
	if(L==NULL)
	exit(EXIT_FAILURE);

	pn=L;
	pn=pn->next;
	for(i=1; i<k; i++)
	{
		if(pn!=NULL&&pn->data==e)
		{
			printf("�ҵ���\n");
			break;
		}
		else
		pn=pn->next;
	}
	if(pn==NULL||pn->data!=e)
	{
		printf("��ѯʧ��\n");
	}
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L) {
	
	LinkedList p;
    LNode *prev = NULL; 
    LNode *curr = *L; 
    while (curr != NULL) 
	{ 
        LNode *nextTemp = curr->next;
        curr->next = prev;
        prev = curr;
        curr = nextTemp;
    }
    
    p=prev;

	while(p->next!=NULL)
	{
		printf("%d\n",p->data);
		p=p->next;
	}
    
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
	
	LNode *fast, *slow;
	
	slow=L; fast=L;
	while(fast!=NULL&&fast->next!=NULL)
	{
		slow=slow->next;
		fast=fast->next->next;
		if(slow==fast)
		{
			printf("�������ɻ�\n");
			break;
		} 
	}
	if(fast==NULL||fast->next==NULL)
	printf("���������ɻ�\n");
	
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L) {
	
	LNode *p, *p1, *p2;
	int k, i;
	k=creat_list_length(*L);
//	printf("k=%d\n",k);
	
	if((*L)->next==NULL||(k%2!=0))
	{
		printf("��ѯʧ��\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		p=*L;
		p1=p->next;
		p2=p1->next;
		for(i=1; i<=(k/2); i++)
		{
			p1->next=p2->next;
			p2->next=p->next;
			p->next=p2;
			p1=p2;
			p2=p2->next; 
			
			if(p2->next==NULL)
			break;
			else
			{
				p=p->next->next;
				p1=p->next;
				p2=p1->next;
			}
			
		}
	}
	
	return *L;
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L) {

	int k, i;
	LNode *p, *q;
	k=creat_list_length(*L);
	p=(*L)->next;
	if(p==NULL)
	{
		printf("��ѯʧ��\n");
	}
	else if(p->next==NULL)
	printf("���������м�ڵ��ǣ�%d\n", p->data);
	else if(k%2==0)
	printf("�����������м�ڵ�\n");
	else
	{
		q=p;
		for(i=1; i<(k/2+1); i++)
		{
			q=q->next;
		}
		printf("���������м�ڵ��ǣ�%d\n", q->data);	
	} 
	 
	 return q;
	 
}

LNode *CreateList_DuL()
{
	int n,length,data,i;
	LinkedList phead,ptemp,pnew;
	phead=(struct LNode *)malloc(LENS);
	if(phead==NULL)
	{
		printf("�ڴ����ʧ�ܣ�\n");
		exit(EXIT_FAILURE);
	}
	
	phead->data=0;
//	phead->prior=NULL;
	phead->next=NULL;
	ptemp=phead;
	
	printf("������Ҫ�����Ľڵ����:");
	scanf("%d",&length);

	for(i=1; i<length+1; i++)
	{
		pnew=(struct LNode *)malloc(LENS);
		if(pnew==NULL)
		{
			printf("�����ڴ�ʧ��");
			exit(EXIT_FAILURE);
		}
		
		printf("�������%d��Ԫ�ص�ֵ��", i); 
		scanf("%d", &data);
		
		pnew->data=data;
		pnew->next=NULL;
	//	pnew->prior=ptemp;	
		ptemp->next=pnew;
		ptemp=pnew;	
	}

	return phead;	
}

int creat_list_length(LNode *p)
{
	int n=0;
	p=p->next;
	while(p!=NULL)
	{
		p=p->next;
		n++;
	}
	return n;	
}



