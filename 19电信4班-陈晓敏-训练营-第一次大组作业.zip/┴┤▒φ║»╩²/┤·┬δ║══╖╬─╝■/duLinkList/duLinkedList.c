#include "../head/duLinkedList.h"
#include <stdlib.h>
#include <stdio.h>
#define LEN sizeof(struct DuLNode)
/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L) {
	
	*L=(struct DuLNode *)malloc(LEN);
	(*L)->next=NULL;
	(*L)->prior=NULL;	
	
	if(!(*L))
	return ERROR;
	else
	return SUCCESS;
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) {
	
	DuLinkedList p;
	if(*L==NULL)
	exit(EXIT_FAILURE);
	
	while(*L)
	{
		p=(*L)->next;
		free(*L);
		*L=p;
	}

}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) {
		
		q->prior=p->prior;
		p->prior->next=q;
		q->next=p;
		p->prior=q;	

}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) {

		if(p->next==NULL)
	{
		p->next=q;
		q->prior=p;
		q->next=NULL;
	}
	else
	{
		q->next=p->next;
		p->next->prior=q;
		p->next=q;
		q->prior=p;
	}	
}

/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) {
	
	if(p->next==NULL)
	p->prior->next=NULL;
	else
	{
		p->prior->next=p->next;
		p->next->prior=p->prior;
	}
	free(p);

}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
void TraverseList_DuL(DuLinkedList L) {
	
	L=L->next;
	while(L!=NULL)
	{
		printf("%d\n",L->data);
		L=L->next;
	}
	printf("�����������\n"); 
	
}

DuLNode *CreateList_DuL()
{
	int n,length,data,i;
	DuLinkedList phead,ptemp,pnew;
	phead=(struct DuLNode *)malloc(LEN);
	if(phead==NULL)
	{
		printf("�ڴ����ʧ�ܣ�\n");
		exit(EXIT_FAILURE);
	}
	
	phead->data=0;
	phead->prior=NULL;
	phead->next=NULL;
	ptemp=phead;
	
	printf("������Ҫ�����Ľڵ����:");
	scanf("%d",&length);

	for(i=1; i<length+1; i++)
	{
		pnew=(struct DuLNode *)malloc(LEN);
		if(pnew==NULL)
		{
			printf("�����ڴ�ʧ��");
			exit(EXIT_FAILURE);
		}
		
		printf("�������%d��Ԫ�ص�ֵ��", i); 
		scanf("%d", &data);
		
		pnew->data=data;
		pnew->next=NULL;
		pnew->prior=ptemp;	
		ptemp->next=pnew;
		ptemp=pnew;	
	}

	return phead;	
}

int creat_list_length(DuLNode *p)
{
	int n=0;
	p=p->next;
	while(p!=NULL)
	{
		p=p->next;
		n++;
	}
	return n;	
}




