﻿// qianrushi.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
//寻找最长回文字符串
char * longest(char * s, int *n)
{
	int left1 = 0, right1 = 0, left2 = 0, right2 = 0;
	int N = strlen(s), start = 0, len = 0;
	//printf("%d\n", strlen(s));
	if (N == 0 || N == 1)
	{
		return(s);
	}
	for (int i = 0; i < N; i++)
	{	
		int a = 0, b = 0;

		left1 = i; right1 = i + 1;
		while (left1 >= 0 && right1 < N && s[left1] == s[right1])
		{
			left1--; right1++;
		}
		a= right1 - left1 - 1;

		left2 = i-1; right2 = i + 1;
		while (left2 >= 0 && right2 < N && s[left2] == s[right2])
		{
			left2--; right2++;
		}
		b= right2 - left2 - 1;

		if (a > b && a > len)
		{   
			start = left1 + 1;
			len = a ;
		}
		else
		if (b > a && b > len)
		{
			start = left2 + 1;
			len = b;
		}
	}
	*n = len;
	s[start + len] = '\0';      
	return s + start;
}

//递归算法
 int findStep(int n) 
 {
	if (n == 0 || n == 1 || n == 2) {
		return n;
	}

	return findStep(n - 1) + findStep(n - 2);
}

 //动态规划算法
int FindStep(int n)
{
	 if (n < 0|| n == 0|| n == 1) 
	 {
		 return n;
	 }
	 
	 int a = 1;
	 int b = 1;
	 int fn = 0;
	 for (int i = 2; i < n + 1; i++) 
	 {
		 fn = a + b;
		 b = a;
		 a = fn;
	 }
	 return fn;
 }

int main()
{
	char s[20];
	int n=0;
	printf("请先输入一段字符串\n");
	scanf("%s", s);
	longest(s, &n);
	if (n == 1)
	{
		printf("该字符串没有回文子字符串\n");
	}
	else
	{
		printf("该字符串的最长回文子字符串为\n");
		puts(longest(s, &n));
	}
	

	int a;
	printf("请输入要走的台阶数\n");
	scanf("%d", &a);
	printf("%d\n", findStep(a));//递归算法
	printf("%d\n", FindStep(a));//动态规划算法

	system("pause");
	return 0;
}

	


// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
