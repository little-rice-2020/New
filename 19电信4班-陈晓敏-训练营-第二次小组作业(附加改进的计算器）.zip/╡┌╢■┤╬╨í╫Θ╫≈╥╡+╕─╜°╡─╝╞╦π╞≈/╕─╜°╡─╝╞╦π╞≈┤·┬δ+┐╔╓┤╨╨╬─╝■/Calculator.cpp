﻿// 计算器.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#define MAX 100


int main()
{
	void suffix(char *ss); /* 计算后缀表达式 */
	void Calculate(double *num, int *i, int *j, char s);    /* 计算结果并入栈 */
	void forcaseA();

	char input;
	int i = 0;
	int j = 0;
	int flag = 1;
	do
	{
		printf("选择你要进行的操作\n");
		printf("a.计算\n""b.退出程序\n");
		input = getchar();
		while (getchar() != '\n')
		{
			continue;
		}
		system("cls");

		switch (input)
		{
			case 'a':
			{
				forcaseA();
				break;
			}
		
			case 'b':
			{
				printf("goodbye\n"); system("pause"); flag = 0; break;
			}

			default:  printf("Your input is wrong! \n"); system("pause"); break;
		}
		
		/*while (getchar() != '\n')
		{
			continue;
		}*/
		system("cls");

	}while (flag);
	
	return 0;

}
	

	/*while(flag)
	{
		char ss[MAX] = { "\0" }; 
		printf("input:\n");
		gets_s(ss);
		suffix(ss);
		puts(ss);

		int i = 0;
		int j = 0;
		
		double k = 0;
		double num[MAX];  
		while (ss[i] != '\0')
		{
			if (ss[i] == '#')
			{
				i++;
				num[j] = (double)(ss[i] - '0');
				i++;
				while (ss[i] != '#'&&ss[i] != '.')
				{
					num[j] = num[j] * 10 + (double)(ss[i] - '0');
					i++;
				}
				k = 10;
				if (ss[i] == '.')
				{
					i++;
					while (ss[i] != '#')
					{
						num[j] = num[j] + ((double)(ss[i] - '0'))/ k;
						i++;
						k = k * 10;
					}
					i++; j++;
				}
				else
				{
					i++; j++;
				}	
			}
			else if (ss[i] >= '0' && ss[i] <= '9')   
			{
				num[j] = (double)(ss[i] - '0'); 
				j++;
				i++;
			}
			else if (ss[i] == '+' || ss[i] == '-' || ss[i] == '*' || ss[i] == '/')
			{
				Calculate(num, &i, &j, ss[i]);   
			}
			else if (ss[i] == '\n')    
			{
				break;
			}
		}
		//printf("%d\n", j);
		printf("result:\n");
		printf("%lf\n", num[0]);

	}
	system("pause");
*/









// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
