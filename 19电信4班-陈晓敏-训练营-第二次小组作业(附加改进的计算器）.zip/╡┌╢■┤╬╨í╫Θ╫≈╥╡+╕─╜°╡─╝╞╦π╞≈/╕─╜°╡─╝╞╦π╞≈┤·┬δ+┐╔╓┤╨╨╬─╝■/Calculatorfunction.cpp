
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#define MAX 100



void PushOperation(char *opera, char *ss, int *op, int *s)
{
	opera[*op] = ss[*s];
	(*op)++;
	(*s)++;
}

void Calculate(double *num, int *i, int *j, char s)
{
	switch (s)
	{
	case '+':
	{
		num[(*j) - 2] = num[(*j) - 2] + num[(*j) - 1];
		//	printf("%lf = %lf + %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '-':
	{
		num[(*j) - 2] = num[(*j) - 2] - num[(*j) - 1];
		//	printf("%lf = %lf - %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '*':
	{
		num[(*j) - 2] = num[(*j) - 2] * num[(*j) - 1];
		//	printf("%lf = %lf * %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	case '/':
	{
		num[(*j) - 2] = num[(*j) - 2] / num[(*j) - 1];
		//	printf("%lf = %lf / %lf\n", num[(*j) - 2], num[(*j) - 2], num[(*j) - 1]);
		(*j)--;
		(*i)++;
		break;
	}
	default:
	{
		exit(0);
	}
	}
}

void suffix(char *ss)
{
	char num[100] = "0";    /* �洢��׺����ʽ */
	char opera[100] = "0";    /* �洢����� */
	/*
	num----j,b
	opera----op,c
	ss----i,a
	*/

	char SS[50] = { '\0' };
	int a=0, b=0, c= strlen(ss);

	if (ss[0] == '-')
	{
		SS[b] = '0';
		b++;
	}
	while (a < c)
	{
		SS[b] = ss[a];
		a++; b++;

		if( (ss[a-1] == '(' && ss[a] == '-') )//�������������
		{
			SS[b] = '0';
			b++;
			//printf("%c", ss[0]);//ע�⣬��%c������%s���������ᱨ�����ʳ�ͻ�Ĵ���
		}
	}
	//printf("%s\n", SS);


//�����ʵĵط�
	/*a = 0; b = 0; c = strlen(SS);
	for (a = 0; a < c; a++)
	{
		ss[b] = SS[a];
		b++;
	}
	printf("yes2\n");
	printf("%s", ss);
*/
	int i, j, op;
	op = i = j = 0;

	while (SS[i] != '\0')
	{	//������λ����С�������
		if((isdigit(SS[i]) && isdigit(SS[i + 1]))||(isdigit(SS[i]) && SS[i+1] == '.'))
		{
			num[j] = '#';
			j++;
			while (isdigit(SS[i])||SS[i]=='.')
			{
				num[j] = SS[i];
				j++;
				i++;
			}
			num[j] = '#';
			j++;
		}
		else
		if (isdigit(SS[i])) /*���ÿ⺯�����ж��Ƿ�Ϊ0~9������ */
		{	
			num[j] = SS[i];
			j++;
			i++;
		}
		else
		{
			switch (SS[i])
			{
		
			case '+':
			{
				if (op == 0)   
				{
					PushOperation(opera, SS, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(' )
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
							op++;
							opera[op - 1] = SS[i];
							i++;

						break;
					}
					case '-':
					{
						//PushOperation(opera, SS, &op, &i);
						/*while ((op - 1) != -1 || opera[op - 1] != '(' || opera[op - 1] != '*'|| opera[op - 1] != '/')
						{
							num[j] = opera[op - 1];    
							j++;
							op--;
						}
						if ((op - 1) == -1)
						{
							op++;
							opera[op - 1] = SS[i];
							i++;
						}
						else if (opera[op - 1] == '(')
						{
							op--;
							i++;
						}
						else if (opera[op - 1] == '*' || opera[op - 1] == '/')
						{

						}*/

						while ((op - 1) != -1 && opera[op - 1] != '(' )
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
							op++;
							opera[op - 1] = SS[i];
							i++;

						break;
					}
					case '*':
					{    
						while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '-':
			{
			/*	if ((SS[i - 1] == '(' && SS[i] == '-'))//�������������
				{
					num[j] = '0';
					j++;
					//printf("%c", ss[0]);//ע�⣬��%c������%s���������ᱨ�����ʳ�ͻ�Ĵ���
				}
				*/
				if (op == 0)
				{
					PushOperation(opera, SS, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						
						break;
					}
					case '-':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '*':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(' )
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '/':
					{
						/*while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						if ((op - 1) != -1)
						{
							op++;
							opera[op - 1] = SS[i];
							i++;
						}
						else
						{
							op--;
							i++;
						}*/

						while ((op - 1) != -1 && opera[op - 1] != '(')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '*':
			{
				if (op == 0)
				{
					PushOperation(opera, SS, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					case '*':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(' && opera[op - 1] != '+' && opera[op - 1] != '-')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						
						break;
					}
					case '/':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1 && opera[op - 1] != '('&&opera[op - 1] != '+' && opera[op - 1] != '-')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '/':
			{
				if (op == 0)
				{
					PushOperation(opera, SS, &op, &i);
					break;
				}
				if (opera[op - 1] == '+' || opera[op - 1] == '-' || opera[op - 1] == '*' || opera[op - 1] == '/' || opera[op - 1] == ')' || opera[op - 1] == '(')
				{
					switch (opera[op - 1])
					{
					case '+':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					case '-':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					case '*':
					{
						//PushOperation(opera, ss, &op, &i);
						while ((op - 1) != -1 && opera[op - 1] != '(' && opera[op - 1] != '+' && opera[op - 1] != '-')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '/':
					{
						while ((op - 1) != -1 && opera[op - 1] != '(' && opera[op - 1] != '+' && opera[op - 1] != '-')
						{
							num[j] = opera[op - 1];
							j++;
							op--;
						}
						op++;
						opera[op - 1] = SS[i];
						i++;
						break;
					}
					case '(':
					{
						PushOperation(opera, SS, &op, &i);
						break;
					}
					}
				}
				break;
			}
			case '(':
			{
				PushOperation(opera, SS, &op, &i);
				break;
			}
			case ')':   
			{
				while (opera[op - 1] != '(')
				{
					num[j] = opera[op - 1]; 
					j++;
					op--;
				}
				op--;
				i++;
				break;
			}
			default:
			{
				printf("�������ʽ������Ҫ��\n");
				exit(0);
			}

			}
		}
	}

	while (op != 0)
	{

		num[j] = opera[op - 1];  
		j++;
		op--;
	}
	num[j] = '\0';
	i = 0;
	while (num[i] != '\0')  
	{
		ss[i] = num[i];
		i++;
	}
	ss[i] = '\0';

}




void forcaseA()
{
	char ss[MAX] = { "\0" };
	printf("input:\n");
	gets_s(ss);
	suffix(ss);
//	puts(ss);
	int i = 0;
	int j = 0;

	double k = 0;
	double num[MAX];
	while (ss[i] != '\0')
	{
		if (ss[i] == '#')
		{
			i++;
			num[j] = (double)(ss[i] - '0');
			i++;
			while (ss[i] != '#'&&ss[i] != '.')
			{
				num[j] = num[j] * 10 + (double)(ss[i] - '0');
				i++;
			}
			k = 10;
			if (ss[i] == '.')
			{
				i++;
				while (ss[i] != '#')
				{
					num[j] = num[j] + ((double)(ss[i] - '0')) / k;
					i++;
					k = k * 10;
				}
				i++; j++;
			}
			else
			{
				i++; j++;
			}
		}
		else if (ss[i] >= '0' && ss[i] <= '9')
		{
			num[j] = (double)(ss[i] - '0');
			j++;
			i++;
		}
		else if (ss[i] == '+' || ss[i] == '-' || ss[i] == '*' || ss[i] == '/')
		{
			Calculate(num, &i, &j, ss[i]);
		}
		else if (ss[i] == '\n')
		{
			break;
		}
	}
	//printf("%d\n", j);
	printf("result:\n");
	printf("%lf\n", num[0]);
	system("pause");
	system("cls");

}
