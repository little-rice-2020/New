/*ʵ����ˮ��*/
#include "reg52.h"
#define uint unsigned int
#define uchar unsigned char
#define time 50000
void delay(uint n)
{
	while(n--);
}

void main()
{
	while(1)
	{	 
		P0 = 0x7f;
		delay(time);
		P0 = 0xbf;
		delay(time);
		P0 = 0xdf;
		delay(time);
		P0 = 0xef;
		delay(time);

		P0 = 0xf7;
		delay(time);
		P0 = 0xfb;
		delay(time);
		P0 = 0xfd;
		delay(time);
		P0 = 0xfe;
		delay(time);
			
	}


} 
		  
