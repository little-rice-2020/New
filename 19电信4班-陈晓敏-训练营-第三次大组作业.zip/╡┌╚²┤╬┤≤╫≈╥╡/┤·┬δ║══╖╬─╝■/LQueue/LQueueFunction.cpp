#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <assert.h>
#include "LQueue.h"
#define INT 1;
#define CHAR 2;
#define DOUBLE 3;
#define STRING 4;

#define MAXQUEUE 10

char xm_type;
char xm_datatype[30];
size_t n = 1;
//����ѡ���������������
void forchoose(LQueue *Q)
{
	int t; char ch; int i;
	//for (i = 0; i < 5; i++)
	{
		printf("��������������ͣ�:\n");
		printf("1. ���� 2. �ַ��� 3. ������(��ȷ��С�����2λ) 4. �ַ���\n");
		scanf("%d", &t);
		while (t < 1 || t>4)
		{
			printf("Ӧ������[1,4]֮���������\n�����䣺");
			scanf("%d", &t);
		}
		ch = getchar();//�����������Ŀո�
		printf("����ӵ����� :");
		switch (t)
		{
		case 1:
		{
			int a;
			scanf("%d", &a);
			EnLQueue(Q, &a);
			//printf("%d\n", *(int*)Q->front->data);
			xm_datatype[Q->length + n - 1] = t;
			//printf("xm_datatype[%d]=%d\n", Q->length + n - 1, xm_datatype[Q->length + n - 1]);
			break;
		}
		case 2:
		{
			char a;
			//system("pause");
			scanf("%c", &a);
			EnLQueue(Q, &a);
			//printf("%c\n", *(char*)Q->front->data);
			xm_datatype[Q->length + n-1] = t;
		//	printf("xm_datatype[%d]=%d\n", Q->length + n - 1, xm_datatype[Q->length + n - 1]);
			break;
		}
		case 3:
		{
			double a;
			scanf("%lf", &a);
			EnLQueue(Q, &a);
			//printf("%lf\n", *(double*)Q->front->data);
			xm_datatype[Q->length + n - 1] = t;
			//printf("xm_datatype[%d]=%d\n", Q->length + n - 1, xm_datatype[Q->length + n - 1]);
			break;
		}
		case 4:
		{
			char a[10];
			printf("��󳤶�Ϊ10��\n");
			scanf("%s", a);
			EnLQueue(Q, a);
			//printf("%s\n", (char*)Q->front->data);
			xm_datatype[Q->length + n - 1] = t;
			//printf("xm_datatype[%d]=%d\n", Q->length + n - 1, xm_datatype[Q->length + n - 1]);
			break;
		}
		}
	}

}

void InitLQueue(LQueue *Q)
{
	Q->front = Q->rear = NULL;
	Q->length = 0;
	printf("���г�ʼ���ɹ�\n");
}

void DestoryLQueue(LQueue *Q)
{
	Node *p;
	while (Q->front)
	{
		p = Q->front->next;
		free(Q->front);
		Q->front = p;
	}
	Q->front = NULL;
	printf("����������\n");
}

Status IsEmptyLQueue(LQueue *const Q)
{
	if (Q->front == NULL)
	{
		printf("�ö���Ϊ��\n");
		return TRUE;
	}
	else
	{
		printf("�ö��в�Ϊ��\n");
		return FALSE;
	}
		
}

Status GetHeadLQueue(LQueue *Q, void *e)
{
	if(Q->front == NULL)
	{
		printf("����Ϊ�գ�û�ж�ͷ��\n");
			return FALSE;
	}
	//e = Q->front->data;
	memcpy(e, Q->front->data, 10);

	if (xm_datatype[n] == 1)
		printf("*(int*)e--> %d\n", *(int*)e);
	if (xm_datatype[n] == 2)
		printf("*(char*)e--> %c\n", *(char*)e);
	if (xm_datatype[n] == 3)
		printf("*(double*)e--> %lf\n", *(double*)e);
	if (xm_datatype[n] == 4)
		printf("(char*)e--> %s\n", (char*)e);

	return TRUE;
}

int LengthLQueue(LQueue *Q)
{
	return Q->length;
}

Status EnLQueue(LQueue *Q, void *data)
{
	Node *Pnew;
	Pnew = (Node *)malloc(sizeof(Node));
	Pnew->data= malloc(MAXQUEUE);//ע���������С
	Pnew->next = NULL;
	//*(Pnew->data) = *data;//ע�ⲻ��������ֵ����Ч
	//printf("%d\n", *(int*)data);//ע��ת����ʽ���Իᱨ��
	
	memcpy(Pnew->data, data, MAXQUEUE);
	Q->length = Q->length + 1;
	if (Q->front==NULL)//�߼��ж��״�
	{
		Q->front = Pnew;
		Q->rear = Pnew;
	//	printf("%d\n", *(int*)Q->front->data);
	}
	else
	{
		Q->rear->next = Pnew;
		Q->rear = Pnew;
	}
	return TRUE;
}

Status DeLQueue(LQueue *Q)
{
	//assert(Q);
	if (Q->front == NULL)
	{
		printf("����Ϊ�գ�ɾ��ʧ�ܣ�\n");
		return FALSE;
	}
	Node *p;
	p = Q->front->next;
	free(Q->front);
	Q->front = p;
	Q->length = Q->length - 1;
	//printf("Q->length1=%d\n", Q->length);
	n++;
	//printf("n=%d\n", n);
	p = NULL;
	return TRUE;
}

void ClearLQueue(LQueue *Q)
{
	Node *p;
	while (Q->front)
	{
		p = Q->front->next;
		free(Q->front);
		Q->front = p;
	}
	Q->front = NULL;
	printf("���������\n");
}

Status TraverseLQueue(LQueue *Q, void(*foo)(void *q))
{
	Node *p;
	if (Q->front == NULL)
	{
		printf("����ĿǰΪ��\n");
		return FALSE;
	}
	size_t i = 1; size_t k = n;
	 p = Q->front;
	while (i <= Q->length)
	{
		xm_type = xm_datatype[k];
		//printf("xm_datatype[%d]=%d\n", i, xm_datatype[k]);
		foo(p->data);
		p = p->next;
		k++;
		i++;
	}
	return TRUE;
}

void LPrint(void *q)
{
	if (xm_type == 1)
		printf("--> %d\n", *(int*)q);
	if (xm_type == 2)
		printf("--> %c\n", *(char*)q);
	if (xm_type == 3)
		printf("--> %.2lf\n", *(double*)q);
	if (xm_type == 4)
		printf("--> %s\n",(char*)q);
}



