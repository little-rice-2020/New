﻿// AQueue.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "AQueue.h"

int main()
{
	void InitAQueue(AQueue *Q);
	void DestoryAQueue(AQueue *Q);
	Status IsFullAQueue(AQueue *const Q);
	Status IsEmptyAQueue(AQueue *const Q);
	Status GetHeadAQueue(AQueue *Q, void *e);
	int LengthAQueue(AQueue *Q);
	Status EnAQueue(AQueue *Q, void *data);
	Status DeAQueue(AQueue *Q);
	void ClearAQueue(AQueue *Q);
	Status TraverseAQueue(AQueue *const Q, void(*foo)(void *q));
	void APrint(void *q);

	AQueue Q;
	void *e=malloc(MAXQUEUE);

	char input, flag = 1;
	int n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0, n6 = 0;
	do
	{
		int i = 0;
		printf("选择你要进行的操作\n");
		printf("a.初始化队列\n""b.销毁队列\n""c.检查队列是否为空\n""d.查看队头元素\n"
			"e.确定队列长度\n""f.入队操作\n""g.出队操作\n""h.清空队列\n""i.查看队列是否已满\n"
			"j.遍历函数操作\n""k.退出操作程序\n");
		input = getchar();
		switch (input)
		{
		case 'a':
		{
			n1 = 1;
			InitAQueue(&Q);
			system("pause");
			break;
		}
		case 'b':
		{
			if (n1 == 1)
			{
				DestoryAQueue(&Q);
				n1 = 0;
			}
			else
				printf("请先初始化函数\n");
			system("pause");
			break; }

		case 'c':
		{
			if (n1 == 1)
			{
				if(!LengthAQueue(&Q))
				{
					printf("队列为空\n");
				}
				else
				{
					printf("队列不为空\n");
				}
				n3 = 1;
			}
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'd':
		{
			if (n1 == 1)
			{
				GetHeadAQueue(&Q, e);
				n4 = 1;
			}
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'e':
		{
			if (n1 == 1)
			{
				printf("该队列长度为: %d\n", LengthAQueue(&Q));
			}
			else
				printf("请先初始化函数\n");

			system("pause");  break;
		}
		case 'f':
		{
			if (n1 == 1)
			{
				forchoose(&Q);
				n5 = 1;
			}
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'g':
		{
			if (n1 == 1 && DeAQueue(&Q))
				printf("删除成功\n");
			else
				printf("删除失败\n");
			system("pause");  break;
		}
		case 'h':
		{
			if (n1 == 1)
				ClearAQueue(&Q);
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'i':
		{
			if (n1 == 1)
				IsFullAQueue(&Q);
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'j':
		{
			if (n1 == 1)
				TraverseAQueue(&Q, APrint);
			else
				printf("请先初始化函数\n");
			system("pause");  break;
		}
		case 'k':  printf("goodbye\n"); system("pause"); flag = 0; break;

		default:  printf("Your input is wrong! \n"); system("pause"); break;
		}
		while (getchar() != '\n')
		{
			continue;
		}
		system("cls");

	} while (flag);


	DestoryAQueue(&Q);
	free(e);

	return 0;
}
