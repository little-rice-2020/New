
#ifndef AQUEUE_H_INCLUDED
#define AQUEUE_H_INCLUDED

#define MAXQUEUE 10
	//ѭ�����нṹ
typedef struct Aqueue
{
	void *data[MAXQUEUE];     
	int front;
	int rear;
	size_t length;        
} AQueue;

typedef enum
{
	FALSE = 0, TRUE = 1
} Status;
extern char xm_type;
extern char xm_datatype[MAXQUEUE];

void forchoose(AQueue *Q);//����ѡ���������������
void InitAQueue(AQueue *Q);
void DestoryAQueue(AQueue *Q);
Status IsFullAQueue(AQueue *const Q);
Status IsEmptyAQueue(AQueue *const Q);
Status GetHeadAQueue(AQueue *Q, void *e);
int LengthAQueue(AQueue *Q);
Status EnAQueue(AQueue *Q, void *data);
Status DeAQueue(AQueue *Q);
void ClearAQueue(AQueue *Q);
Status TraverseAQueue(AQueue *const Q, void(*foo)(void *q));
void APrint(void *q);

#endif // AQUEUE_H_INCLUDED


